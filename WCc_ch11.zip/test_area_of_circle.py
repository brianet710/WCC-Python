from area_of_circle import sphereArea 


def test_sphereArea10():
    """Is the computation accurate?"""
    ten =  sphereArea(10)
    assert ten == 1256.6368

    
    
def test_sphereArea5():
    """Is the computation accurate?"""
    five =  sphereArea(5)
    assert five == 314.1592
