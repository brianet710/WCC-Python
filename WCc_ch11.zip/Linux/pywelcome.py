#!/bin/python
# a greeting script

print('Welcome you')
