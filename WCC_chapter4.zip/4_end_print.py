''' More about print()
Python’s print() function comes with a parameter called ‘end’.
By default, the value of this parameter is ‘\n’(newline)
End allows us to replace '\n' with anything we choose.
'''
print()
print("Hello", end = '...?.... ')
print("Sentence number two begins here on the same line.")
print()

print("Hello") # default behavior of print
print('I am the last sentence')