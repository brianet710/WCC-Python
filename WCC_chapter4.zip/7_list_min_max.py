# min() max() & sum() functions
numbers = [10, 3, 28, 16, 95, -5, 43, 8]
print(numbers)

print( min(numbers) )   # print the minium value in the list numbers
print( max(numbers) )   # print the maximum value in the list numbers
print( sum(numbers) )   # print the summation of all values in the list numbers
print('')
names = ['Charli','Zuli','Ali']  #be cautious of case
print(min(names))
print(max(names))
#print(sum(a))   TypeError. Strings cannot be summed

# ASCII order: Numbers, Uppercase, lowercase
# # See Ascii-chart 