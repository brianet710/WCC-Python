# shorthand notation for populating a list

# This list comprehension generates a list in one line
# this generates a list of all cubes from 1 and 10 inclusive
cubes = [v**3 for v in range(1, 10)]

'''
Line 5 is equivalent of lines 9,10 and 11
cubes =[]
for v in range(1,10):
     cubes.append(v**3)
'''

# print the list cubes
for n in cubes:
    print(n, end=', ')
