# The zip() function groups together related elements from different lists (or tuples).

# lists of unequivalent length
vehicles = ['car', 'boat', 'plane', 'waterski']
brand = ['Lexus', 'Baha', 'LearJet']

# the list with least elements determines how many iterations
for (v,b) in zip(vehicles, brand): #note 2 looping variables
    print(f"{v:10}{b}")

print("")
# The lists are unchanged
print(vehicles)
