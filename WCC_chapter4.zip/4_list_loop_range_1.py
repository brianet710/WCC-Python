''' The range() function returns a sequence of numbers 
    starting from 0 by default, and increments by 1 (by default),
      and stops BEFOREa specified index
       range(start, stop-before, step)
         '''
print()
# for loop used for counting from 1 up to but not including 3
for v in range(1, 3):    
    print(v, end=" ")   

print("\n")

# for loop used for counting from -5 to positive 4
for v in range(-5, 5):
    print(v, end=",")   # print a comma after, instead of a newline after

print("\n")
# a number line
# -5 -4 -3 -2 -1 0 1 2 3 4 5
