
#import emoji 
import emoji

print(emoji.emojize(":grinning_face_with_big_eyes:"))
print(emoji.emojize(":winking_face_with_tongue:"))
print(emoji.emojize(":zipper-mouth_face:"))

print()
print("Unicode Character Encoding")

omega = "\u03A9"
print(omega)  

umbrella =  "\u2602 "
print(umbrella)

greeting = "Hello, World! \u4F60\u597D" 
print(greeting)  
print()

# How can we print \u03A9 so that it is not interpreted as a unicode character?