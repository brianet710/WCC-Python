# Loop Range - example 3 of 3
cubes = []   # empty list

# use a loop with range to generate list content
for v in range(1,10):
    cubes.append(v**3)
print (cubes)
# print all elements of the list cubes
for c in cubes:
    print(c, end = "   ")
