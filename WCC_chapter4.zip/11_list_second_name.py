# Two references to the same list

# even numbers between 2 and 10 inclusive
evens = [2, 4, 6, 8, 10]
print(evens)
print("")

# create a second label for the existing list
numbers = evens    #numbers and evens reference the same list

print(numbers)
print("")

# remove the last two elements of evens, add an element to numbers
evens.pop()
evens.pop()
numbers.append(25)

# print proves that evens and numbers are in fact the same list
print(evens)
print("")
print(numbers)
print("")
