# Chapter 4 Working with Lists II
# a list of integers called numbers
numbers = [1, 2, 3]
# print the entire list with brackets
print(numbers)
#Accessing individual elements is ok for short lists
print(numbers[0])
print(numbers[1])
print(numbers[2])
print("")
'''Repetitive execution of the same block of code 
 over and over is referred to as looping '''
for n in numbers:
    print(n)    # indented code is the loop body. n is a looping variable
print("This string is outside the loop")  

''' iterate through the list, printing each element twice, one at a time
    the number of iterations is determined by the number of list elements
     each statement in the loop body executes once for every iteration.'''
numbers = [3, 4, 5]
for n in numbers:
    print(n)  
    print('hello')      #indented so part of the loop
    print(n)        #indented so part of the loop

print("Goodbye")     # code that is not indented will execute when the loop ends.
