#Slicing stepping      [start:end*:step]   Default =[0:-1:1]
grades =[87, 73, 66, 92, 69, 81]

print(grades[0:6:2]) #start at 0; go till 5; step by 2
print(grades[0::2])  #start at 0; go till end; step by 2
print(grades[::2])   #start at 0; go till end; step by 2
print(grades[1:6:3]) #start at 1; go till 5; step by 3
print(grades[::])    #start at 0; go till end; step by 1

print(grades[::-1])  #reverse the list using slicing
