# Replacing a tuple with all new values

# a tuple is an immutable object (an object that cannot be modified)
_3dPoint = (5, 10, 3) # a 3 dimensional point with x y and z values
print(_3dPoint[0])
print(_3dPoint[1])
print(_3dPoint[2])
print("")

# this works, because we are replacing the tuple rather then modifying it
_3dPoint = (10, 20, 30)
print(_3dPoint[0])
print(_3dPoint[1])
print(_3dPoint[2])
print("")
