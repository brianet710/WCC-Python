# Slicing is a way to select a subset of elements

# a list comprehension creates a list of all even numbers between 0 and 20 inclusive
evens = [v*2 for v in range(0, 11)]
print(evens)

# slicing : print elements with the index 0 1 2 3
print(evens[0:4])

# slicing : print element with the index 2
print(evens[2:3])

# slicing : print elements from the start to up to index 6 (0-5)
print(evens[:6])

# slicing : print elements from index 6 to the end (6-10)
print(evens[6:])

# slicing : print last three elements
print(evens[-3:])

print("")
'''Rule:
If we omit the number before : we begin at 0
If we omit the number after : we end at list's end
 '''
