# Copy a list to a 2nd list
evens = [2, 4, 6, 8, 10]
print(evens)
print("")

# numbers becomes an identical copy of evens
numbers = evens[:]   #numbers and evens are 2 distinct lists

print(numbers)
print("")

# remove the last two elements of evens, add an element to numbers
evens.pop()
evens.pop()
numbers.append(25)

# print proves that the lists are different objects
print(evens)
print("")
print(numbers)
print("")

# use slicing to duplicate part of the list to a new list
nums = evens[1:3]
print(nums)
