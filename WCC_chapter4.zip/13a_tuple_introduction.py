# Tuples are unchangeable, meaning that we cannot change,
# add or remove elements after the tuple has been created.*
points = (5, 10, 3)
print(points[0])
print(points[1])
print(points[2])
print("")

# this causes an error, because we are trying to modify a tuple which is immutable
points[0] = 20
print("")
