# The sep parameter is used to separate print arguments.
#Arguments are comma separated.
print("This","line", "has", 5, "arguments")

#\n provides new line after printing the year
print('10','04','2024', sep='-', end='\n')
 
print('Red','Green','Blue', sep=', ', end='@')
print('WCC rocks')