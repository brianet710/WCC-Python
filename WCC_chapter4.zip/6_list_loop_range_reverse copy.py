# Reverse Direction
# Begin at 4 and stop at 0
print()
for n in range(5):
    print(n, end = ' ' )

#Using a negative step argument to go in reverse
print() 
for n in range(5, 0, -1):
    print(n, end= ' ')
    
# Note that in this last example 0 is not included in output
