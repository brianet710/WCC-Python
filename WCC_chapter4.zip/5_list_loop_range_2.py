# Loop range - example 2 of 3

# for loop used for counting from 0 to up to but not including 10
# The loop variable <v> will increment by 1 with each iteration.
for v in range(10): # a single parameter means start at 0
    print(v, end=", ")   #comma space
print("\n")
# for loop used for counting from 1 to up to but not including 11
# stepping by 2    ---   range(start, stop, step)
for v in range(1, 11, 2):
    print(v, end=" ")   # print a comma after, instead of a newline after
print("\n")

# for loop used for counting from 0 to up to but not including 12
# skipping by 3
for v in range(0, 12, 2):
    print(v, end=" - ")  # print a hyphen instead of a newline

print("\n")
