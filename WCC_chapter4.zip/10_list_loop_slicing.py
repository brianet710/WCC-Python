# Slicing within a for loop

evens = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
# loop through a slice of a list (first 3 elements)
for n in evens[:3]:
    print(n)
