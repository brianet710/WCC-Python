# Looping through a list of strings

vehicles = ['car','boat', 'plane']
# the body of this loop consists of a single statement
# The looping variable is v
for v in vehicles:
    print(f"I will travel by {v}.")
    
print("\n\tAu Revoir")     # code that is not indented is not part of the loop

# The above for loop has 3 iterations
#If our list grew to 5 elements, we would loop 5 times
