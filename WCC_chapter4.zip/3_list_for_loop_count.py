# Counting iteratons
vehicle = ['car','boat', 'plane']

# for every iteration of the for loop:
# 1. print the current list item as part of a string
# 2. increment the count variable (add 1 to count)
count = 0
for v in vehicle:
    print(f"We will travel by {v}.")
    count = count + 1 #increment count
    

# the count variable tracks the loop iterations
print()
print("We will travel "+ str(count) + " ways.")

#note: all statements which form the loop body
# must be indented the same number of spaces
# You already know another technique to count the number of vehicles.
