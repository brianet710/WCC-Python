# Zip works with related lists

# create three lists of equivalent length
vehicles = ['car', 'boat', 'plane']
brand = ['Lexus', 'Baha', 'LearJet']
cost = [50000, 100000, 15000000]

# zip is used with a for loop
for (v,b,c) in zip(vehicles, brand, cost):
    print(f"{v:10}{b:10}{c}")
    #print(v, b, c)  # produces a space separator
print("")
