#WCC Chapter 3 Lab Solutions
#question 1
mycourses = ["et710","et574","eng310"]
print(mycourses[2])
print(mycourses[0])
print("")

#question 2
courses = ['et574','et575','et580','et585','et725']
print(courses)
number = len(courses)
print("i am taking " + str(number) + " courses")
print("")


#question 3
courses = ['et574','et575','et580','et585','et725']
courses.sort(reverse=True)
print(courses)
print("")


#question 4
letters = ['a','b','c','d','e']
print(letters)
print(letters[-2])
letters.reverse()
print(letters)
print(letters[-3])
letters[1] = 'D'
letters[-2] = 'B'
print(letters)
letters.sort()
print(letters)
print("")

#question 5
grades = []
grades.extend([92, 51, 83, 37,72])
print(grades)
average = sum(grades) / len(grades)
print(f"Average: {average:.2f}")
grades.sort()
median = len(grades) // 2  
print (f"Median: {grades[median]}")
grades.remove(51)
grades.remove(37)
print(grades)
new_average = sum(grades) / len(grades)
print(f"Average: {new_average:.2f}")


#https://www.quora.com/How-do-I-find-the-median-value-in-Python
 
nums = [1, 2, 3, 4] 
     
#Sort the list from smallest to largest. 
nums.sort() 
     
#Find the median. 
length = len(nums) 
if (length % 2 == 0): 
    median = (nums[(length)//2] + nums[(length)//2-1]) / 2 
else: 
    median = nums[(length-1)//2] 
     
#Display the result. 
print(f"The median of the list {nums} is {median}") 

#using the statistics module method 
import statistics 
data = [1, 3, 3, 6, 7, 8, 9] 
median = statistics.median(data) 
print(f"The median of the list {data} is ", median) 