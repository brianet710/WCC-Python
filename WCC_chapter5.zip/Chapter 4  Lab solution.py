# a) Implement a list of the numbers 1 2 3 4 5.
numbers = [1, 2, 3, 4, 5]

# b) Use a loop upon this list to compute and print the multiplication table of the number 3.
multiplicand = 3

for number in numbers:
    result = number * multiplicand
    print(f"{number} * {multiplicand} = {result}")



2
# a) Implement an empty list.
numbers_list = []

# b) Use a loop and range to store the values 1 2 3 4 5 6 7 8 9 10 in the list.
for num in range(1, 11):
    numbers_list.append(num)

# c) Use a loop to compute and print the square of each value in the list on a single line separated by spaces.
squares_list = [num ** 2 for num in numbers_list]
squares_str = " ".join(map(str, squares_list))
print(squares_str)





# a) Implement an empty list.
product_list = []

# b) Use a loop and range with the step parameter to make a list containing the product of 0 through 10 multiplied by 5 inclusive.
for num in range(0, 11, 1):
    product = num * 5
    product_list.append(product)

# c) Print the list on a comma separated line.
product_str = ", ".join(map(str, product_list))
print(product_str)





# a) Implement a list comprehension that creates a list of all odd numbers between 1 and 20 inclusive.
odd_numbers = [num for num in range(1, 21) if num % 2 != 0]

# b) Print the list with the elements separated by a space.
odd_numbers_str = " ".join(map(str, odd_numbers))
print(odd_numbers_str)





# a) Use a list comprehension to generate a list of all even numbers from 5 to 50 inclusive. Print the list.
even_numbers = [num for num in range(5, 51) if num % 2 == 0]
print(even_numbers)

# b) Use slicing to print the first five numbers in the list.
first_five = even_numbers[:5]
print(first_five)

# c) Use slicing to print the last five numbers in the list. Hint: use len()
last_five = even_numbers[-5:]
print(last_five)

# d) Use slicing to print all odd numbers between 25 and 30 inclusive.
odd_numbers_between_25_and_30 = [num for num in range(25, 31) if num % 2 != 0]
print(odd_numbers_between_25_and_30)




# a) Think of at least three different animals that would be a good pet.
# b) Store the names of these animals in a list.
pet_animals = ['dog', 'cat', 'parrot']

# c) Use a for loop to print out the name of each animal on a single line separated by commas.
for animal in pet_animals:
    print(animal, end=', ')

# d) Outside of the loop print a general statement about pets.
print("\nAny of these animals would make a great pet!")








 # a) Create a list comprehension of multiples of 6 from 0 to 10 inclusive.
multiples_of_6 = [num * 6 for num in range(11)]

# b) Print this list as displayed in the output example.
print(multiples_of_6)

# c) Create a second empty list.
second_list = []

# d) Use a loop to insert all elements from the first list to the second list.
# Before storing into the new list, divide each copied element by 2.
# This results in a new list of all multiples of 3 from 0 to 10 inclusive.
for num in multiples_of_6:
    second_list.append(num // 2)

# e) Print the second list as displayed in the output example.
print(second_list)

# f) Use slicing to copy the second list to a new third list.
third_list = second_list[:]

# g) Use a loop to multiply and store each element of the third list by 10.
# This will result in a list whose elements are 10 times greater than the previous list.
for i in range(len(third_list)):
    third_list[i] *= 10

# h) Print the third list as displayed in the output example.
print(third_list)

