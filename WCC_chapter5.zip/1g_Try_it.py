'''We have recorded student exam grades as follows:
sue_passed=True
jon_passed=False
eve_passed=True
ken_passed =False

Write the code using complex boolean expressions
to answer the following?
Did eve and sue both pass?
Did either ken or eve fail?
Did jon and sue both pass?

You do not need to declare any variables.
Simply use True and False based on the given data
'''