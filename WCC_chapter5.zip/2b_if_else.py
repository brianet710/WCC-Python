# if else (otherwise)
a = 2; b = 2

''' if the condition is true then execute line 8, 
     otherwise execute line 10
'''
if a == 1:   # if True, the else clause is skipped
    print("A is 1")
else:
    print("A is not 1")

# if the condition is true run line 12, otherwise run line 14
if a != b:
    print("A is not equal to b")
else:
    print("A is equal to b")
# the if clause or the else clause will run, never both.
