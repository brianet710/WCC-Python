# The 'in' keyword is used to check if a value
# is present in a sequence

vehicles = ['bike', 'boat', 'car', 'motorcycle', 'truck']

# is 'bike' is in the list vehicles? True
print('bike' in vehicles)
print("")

# is 'plane' is in the list vehicles? False
print('plane' in vehicles)
print("")

# use an if statement to execute code if 'boat' is in vehicles
if 'boat' in vehicles:
    print("We can travel by boat.")
print("")

# use an if statement to execute code if 'car' is in vehicles
if 'boat' in vehicles and 'car' in vehicles:
    print("We can travel by boat and we can travel by car.")
