'''
The in keyword has two purposes:
It is used to iterate through a sequence in a for loop:
It is used to check if a value is present in a sequence (string, list, range)
'''
print("in keyword: strings")
pet = "python"
print ('python' in pet) # full string match True
print ('thon' in pet)   # sub-string match True
print('\nin keyword: lists')
hobbies=["chess", "hiking", "ping-pong"]
print("chess" in hobbies) # full string match True
print("hess" in hobbies) # sub-string match False
print("\nin keyword: range")
n = 6
print(n in range(0, 5))
print(n in range(0, 7))
