# multiple ifs
a = 1; b = 4
# if statements, unlike if-elif, are completely independent.
if a < 10:
    print("A is less than 10")

if a == 1:
    print("A is 1")

if a >= 10 and a != 1:
    print("A is not less than 10 and not equal to 1.")

if b%2 == 0: # Is B a multiple of 2?
    print("B is a multiple of 2.")

if b%4 == 0: # Is B a multiple of 4?
    print("B is a multiple of 4.")

if b%2 != 0 and b%4 != 0:
    print("B is not a multiple of 2 nor 4.")
