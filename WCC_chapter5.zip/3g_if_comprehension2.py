#list comprehension with else-if
#Replace all negative prices with zero

original_prices = [1.25, -9.45, 10.22, -5.92, 1.16]

revised= [price if price > 0 else 0 for price in original_prices]

print(revised)

#https://realpython.com/list-comprehension-python/