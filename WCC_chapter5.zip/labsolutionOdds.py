odds = [o for o in range(1, 20, 2)]
evens = [e for e in range(0,20,2)]
randoms = [17, 3, 6, 18, 12, 10, 1, 5]
print (odds,evens, sep='/')

allNums =[odds, evens,randoms]
print("The length of allNums is", end=" ")
print(len(allNums))
print(allNums)
