# If statements nested inside a for loop
numbers = [1,2,3,4,5,6,7,8,9,10]

for n in numbers:
    if n > 5:
        print(f"{n} is greater than 5.")
    elif n <5:
        print(f"{n} is less than 5.")
print("")

for n in numbers:
    if n%2 == 0:  # is n an even number?
        print(f"{n} is even.")
