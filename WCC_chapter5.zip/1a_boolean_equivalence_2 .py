''' What is True; what is False?
Most values are evaluated to True if they have some sort of content.
'''
print(" ")
a = "somestring"
print (bool(a))
print (bool(7), end = " "); print (bool(-7))
print(bool(True))
print (bool(" I am a string"))
myList=[1,2]; print(bool(myList))
# Empty strings, empty lists, 0, False and None evaluate to False
print("")
print (bool(""))
print (bool(0))
print (bool(False))
print (bool(None))
empty =[]
print (bool(empty))
