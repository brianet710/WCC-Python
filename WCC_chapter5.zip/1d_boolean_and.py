# Boolean 'and' operator
# Boolean Truth Tables: and 

# a b    a and b
# T T      T
# T F      F
# F T      F
# F F      F

#True and False are Python data types
print(True and True)
print(True and False)
print(False and True)
print(False and False)

print("")

# assigning boolean values to variables
a = True        # boolean is a datatype
b = True
c = False

print(a and b)
print(a and c)

print("")

x =type(a)
print(x)
#equivalent of lines 28 and 29
print(type(a))