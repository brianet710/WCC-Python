# complex boolean expressions
a = 1; b = 1; c = 2; d = 2 # Four assignment statements
# complex boolean conditions
#python will 1st evaluate the expression
# on the left and right independently
# and then evaluate using the boolean operator.
print(a == b or b == c)    # true  false
print(a == c and b == c)   # false  false
print(a != c and b != c)
print(a < b or b >= c) #false false
print(d >= b and a <= c)
