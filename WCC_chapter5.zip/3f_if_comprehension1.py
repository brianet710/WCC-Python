# Remove failing grades revisited (Homework 3)
# List comprehensions are useful for modifying lists
#Best practice is to not modify elements of a list you are looping through
grades = [ 72, 83, 37, 96, 51, 25, 37]
print(grades)

#Solution using list comprehension
# This behaves like an if nested within a for
passing = [g for g in grades if g >60]
print(passing)
print(grades)
