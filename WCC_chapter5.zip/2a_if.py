''' Decision making is required when we want to act
     only if a certain condition is satisfied.
     The if statement lets us evaluate a condition
     and run a block of code if that condition is True'''
a = 1; b = 2

if a == b:
    print("a is equal to b") 
if b != a:  
    print("b is not equal to a")
print("")

if a == 1 and b > a:
    print("A is equivalent to 1") #if body statement 1
    print("B is greater than A")  #if body statement 2
if True:
    print('oui')
if False:
    print('non')
if not False:
    print("true")
          