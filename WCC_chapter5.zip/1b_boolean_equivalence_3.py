# Equality Operators: is equal to; is not equal to
# assign a to reference the value 1, b to reference the value 2
a = 1
b = 2

# Boolean. Is a equal to 1? (True or False)
print(a == 1)
# Boolean condition: Is b equal 1? (True or False)
print(b == 1)
# Boolean condition: Is a equal to b? (True or False)
print(a == b)
# Boolean condition: Is a NOT equal to b? (True or False)
print(a != b)
