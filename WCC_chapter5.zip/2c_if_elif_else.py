#if elif   if elif else
a = 1; b = 2

# Unlike else, elif is a conditional test
if a == 2:      # false, so line 6 does not run
    print("A is 2")
elif a == 1:    # true line 8 runs.
    print("A is 1")

# If neither condition is true, do nothing.
if a == b:      # false, so code does not run
    print("A is equal to b")
elif a > b:     # false so code does not run
    print("A is greater than b")
# if neither condition is True, execute the code associated with the else.
if a == b:      # false, so code does not run
    print("A is equal to b")
elif a > b:     # false so code does not run
    print("A is greater than b")
else:           # true so code runs
    print("A is less than b")
