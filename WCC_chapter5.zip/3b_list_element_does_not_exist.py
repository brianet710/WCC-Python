# Not in (the opposite of in)

vehicles = ['bike', 'boat', 'car', 'motorcycle', 'truck']

# is 'bike' not in the list vehicles? False, it is in the list
print('bike' not in vehicles)
print("")

# is 'plane' in the list vehicles? False
print('plane' in vehicles)
print("")

# If waterski is not in the list, print the following
if 'waterski' not in vehicles:
    print("We cannot travel by waterski.")
print("")

# complex statement
if 'plane' not in vehicles and 'car' in vehicles:
    print("We cannot travel by plane.")
    print("We can travel by car.")

print("")
