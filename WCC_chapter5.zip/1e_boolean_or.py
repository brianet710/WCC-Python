 #Boolean 'or' operator

# Truth Tables: or (either)
# a b   a or b
# T T   T
# T F   T
# F T   T
# F F   F

print(True or True)
print(True or False)
print(False or True)
print(False or False)
print("")

# assigning boolean values to variables
a = True
b = True
c = False

print(a or b)
print(a or c)

print("")
