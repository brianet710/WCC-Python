# if elif else
a = 1; b = 4
# The first condition to be true is the only code that is executed.
if a < 10:
    print("A is less than 10") # python skips the elif and else clause
elif a == 1:
    print("A is 1")
else:
    print("A is not less than 10 and not equal to 1.")

# The first condition to be true, executes its code, and exits the structure.
if b%2 == 0: # Is B a multiple of 2?
    print("B is a multiple of 2.")
elif b%4 == 0: # Is B a multiple of 4?
    print("B is a multiple of 4.")
else:
    print("B is not a multiple of 2 nor 4.")

print("")
