'''
A Boolean expression is a statement that is either True or False
 e.g. Is x equal to y? ...
The double equal sign == is the equality operator.
 '''
print()
print(5 == 3+3)
print(7 >= 4+3)
print(bool(7 == 4+3))

# We can assign a comparison operation result to a var
sum = 5==3+2
print(sum)
print(type(sum))

a = "Hi"
b = "hi"
# Boolean expression example: Case sensitive comparison of a and b.
print()
print(a == b)  # python will evaluate this to be True or False
print()
# Here is how to implement a case insensitive comparison.
print(a.lower() == b.lower())

#Python Comparison Operators
# https://www.w3schools.com/python/gloss_python_comparison_operators.asp
