# Is a list empty?
numbers = []

# line 5 will evaluate to false if the list is empty
if numbers:
    print("There are numbers.")
else:
    print("There are no numbers.")

vehicles = ['car', 'truck', 'boat']

# if vehicles is true if the list has at least one element.
if vehicles:
    print("There are vehicles.")
else:
    print("There are no vehicles.")
