# Greater than, Less than, equal to
a = 1
b = 2
print(a > b) # is a greater than b?
print(a < b) # is a less than b?
print(a >= b) #is a greater than or equal to b?
print(a <= b) #is a less than or equal to b?
c = 2
print(b <= c)
print(c >= b)
