'''
Match case blocks are a replacement of the ‘if..elif..else’ blocks.
Both are ways of testing a variable against a number of possible values
and executing different instructions based on the result.
Line 23, case _:  is the equivalent of the else clause (the fall-through)
In other languages match is called switch
'''

#https://www.udacity.com/blog/2021/10/python-match-case-statement-example-alternatives.html

#cpuModel= "celeron"
#cpuModel= "core i6"
cpuModel= "core i9"
# The match statement evaluates the variable's value
match cpuModel:
  case "celeron":
        print ("Forget about it and play Minesweeper instead...")
  case "core i3":
        print ("Good luck with that ;)")
  case "core i7":
        print ("Yeah, you should be fine.")
  case "core i9":
        print ("I'm jealous!")
  case _: # the underscore character is used as a catch-all.
        print ("Is that even a thing?")
