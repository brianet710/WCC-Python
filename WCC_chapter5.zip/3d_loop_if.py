# for loop nested in if
emergency_contacts=(6311234, 6319988, 6315432)
alarm =False
alarm=True  # external alarm (AD analog-digital connect)
if alarm == True:
    print('Red Alert: Text the Security Team members')
    for teamMembers in emergency_contacts:
        print(teamMembers, end="  ")
else:
    print('No alerts')
