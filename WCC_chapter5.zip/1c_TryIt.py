'''
Assign a variable to the sum of 19 and 17
Assign another var to the product of 9 and 4
Compare these 2 variables for equality and
print the answer.

Write code to solve below using given data.
Did car_a use more gas?
car_a gets 20mpg and travelled 220 miles.
car_b gets 25mpg and travelled 275 miles.

'''