# Sorting a dictionary
student = {'name': 'Emmy','major': 'Art','age': '21','id': '103900600'
}
print(student)
print("")

# temporarily sort the keys lexicographically (ASCII values)
# Numbers* then uppercase then lowercase.
for k in sorted(student.keys()):
    print(k)
print("")


# temporarily sort the values lexicographically
for v in sorted(student.values()):
    print(v)

print("")
print(student)