#Ch5 Lab Q5
grades = [95,63,80,53,90,56]
'''
sum = 0 #keep running total of passing grade sum
count = 0 #keep count of how many grades are passing
for g in grades:
    if g >= 64:
        count += 1      # count = count + 1
        sum += g        # sum = sum + present grade
print(f"Average of the passing grades is {sum/count:.2f}.")
print()
'''
print('Using list comprehension')
grades = [95,63,80,53,90,56]
passing_grades = [g for g in grades if g >63]
print(passing_grades)
print(sum(passing_grades))
print(len(passing_grades))
print(sum(passing_grades)/len(passing_grades))
print(round(sum(passing_grades)/len(passing_grades)))
