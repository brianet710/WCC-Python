# Ch 5 Lab Q2
num = 6

# order matters: the most specific conditions should be checked first
if num%4==0:    # most specific condition
    print(f"{num} is divisible by 4.")
elif num%2==0:  # least specific condition
    print(f"{num} is divisible by 2.")
else:           # if none of the above are true, do this
    print(f"{num} is not divisible by 2 or 4.")
