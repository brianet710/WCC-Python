# Ch 5 Lab Q3
# Is it even and greater than 50?
# Is it negative and odd?

num = -1001
if num>50 and num%2 == 0:
    print(f"{num} is a positive even integer great than 50.")
elif num<0 and num%2 != 0:
    print(f"{num} is a negative odd integer.")
