#Ch5 Lab Q6

li = list (range(1,31))
#multiple of Three or Five
motf = [n for n in li if n % 3 == 0 or n % 5 == 0]
print ( motf, end = " ")
#Multiple of Three
mot = [n for n in li if n % 3 == 0 ]
print("\n")
print(mot, end= " ")
#Not a multiple of Three or Five
nmotof = [n for n in li if n % 3 != 0 and n % 5 !=0]
print("\n")
print(nmotof, end= " ")
