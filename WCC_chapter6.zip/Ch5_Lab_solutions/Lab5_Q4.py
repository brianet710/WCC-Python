# Ch 5 Lab Q4
# SUNY Grade: number to letter conversion
final_grade = 22
if final_grade >= 96:
    print(f"{final_grade} is a grade of A.")
elif final_grade >=64:
    print(f"{final_grade} is a passing grade.")
else:
    print(f"{final_grade} is NOT a passing grade.")
