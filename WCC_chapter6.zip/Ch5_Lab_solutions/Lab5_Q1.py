# Ch5 Lab Q1

n = 25
if n%5==0 and n%3 ==0:     
    print(n,"is divisible by 3 and 5 ")
elif n%3==0:     
    print(n, " is divisible by 3 ")
elif n%5==0:
     print(n, " is divisible by 5 ")
