# The in keyword used with dictionaries
student = {'name': 'John','major': 'CSIS','age': 20,'id': 4569444
}
print(student)
print("")

# verify that a key exists in a dictionary
if 'id' in student.keys():
    print('id is a key in student')
print("")

# verify that a key does not exist in a dictionary
if 'job' not in student.keys():
    print('job is not a key in student')
print("")

# verify that a value exists in a dictionary
if 'John' in student.values():
    print('John is a value in student')
print("")

# verify that a value does NOT exist in a dictionary
if 'GPA' != student.values():
    print('GPA is not a value in student')
print("")
