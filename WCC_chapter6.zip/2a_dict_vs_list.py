#  A dictionary implementation of our vehicles lists

vehicles=['car', 'boat', 'plane']
brand=['subaru', 'baja', 'cesna']
cost_k=[35, 75, 150]
# 3 dictionaries
vehicle1 = {'type':'car', 'brand':'subaru', 'cost_k': 35}
vehicle2 = {'type':'boat', 'brand':'baja', 'cost_k': 75}
vehicle3 = {'type':'plane', 'brand':'cesna', 'cost_k': 150}
print(vehicle1)
print(vehicle2['brand'])
print(vehicle3['cost_k'])
