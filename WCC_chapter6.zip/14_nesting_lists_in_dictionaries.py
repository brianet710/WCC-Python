# nesting lists in dictionaries
#the value for the key grades is a list
#key:value, key:value, key:value, key:value ...
student = {'name': 'Luis','grades': [76,83,91]}

# print dictionary data, including the nested list
print(student['name'])
for g in student['grades']: # 3 iterations
    print(g, end = " ")
print("")

# grades is a dictionary key
print("Access individual elements of a list nested in a dictionary:")
print(student['grades'][-1], end=" ")
print(student['grades'][1], end=" ")
print(student['grades'][0], end=" ")
