# dictionary values can be of any complex type

# values can be lists
vehicles = {
    'cars': ['bmw', 'lexus', 'acura'],
    'boats': ['donzi', 'searay', 'baha'],
    'motorcycles': ['kawasaki', 'ducati', 'harley']
}
print(vehicles)
print("")

# values can be dictionaries
students = {
    's1': {'name': 'Cindy', 'major': 'CSIS'},
    's2': {'name': 'Carl', 'major': 'IIT'},
    's3': {'name': 'Cynthia', 'major': 'CT'}
}
print(students)
print("")
