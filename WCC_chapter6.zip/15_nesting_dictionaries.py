# nesting dictionaries within dictionaries
p1 = {
    'name': 'Anna',
    'favorites': { 'sport': 'football', 'color': 'green' }
}
p2 = {
    'name': 'Doris',
    'favorites': { 'sport': 'biking', 'color': 'black' }}
# person will be a list of dicts (which contain other dicts)
persons = []
persons.append(p1)
persons.append(p2)

# iterate through each persons favorite sport
for p in persons:   #this will iterate twice. Why?
    print(f"{p['name']:6}: ", end=" ") # print the name
    print(p['favorites']['sport'])     # print the sport
print("")
''' 
Remember when you see [], we are referencing a value
by supplying a key
'''
