# Dictionary get() method
student = {
    'name': 'John',
    'major': 'CSIS',
    'age': 20,
    'id': 40
}
print(student)
print("")

# get method for dictionaries
#The get() method returns the value associated with the specified key.
#dictionary.get(keyname, value(msg))
#Optional. A value/message to return if the specified key does not exist.
print(student.get('name'))
print("")

# get method where a key does not exist
print(student.get('address')) #returns None
print("")

# get method to output an error if the key does not exist
print(student.get('address', "hey it ain't there"))
print("")
