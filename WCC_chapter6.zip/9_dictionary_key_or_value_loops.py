# Accessing Dictionary Keys & values
student = {
    'name': 'John','major': 'CSIS','age': 20,'id': 509544
}
print(student);  print("")

# For loop defaults to looping through keys
for k in student:
    print(f"{k}")
print(" ")

# another way to access keys
for k in student.keys():
    print(f"{k}")
print("")

# access values using key as an index
for k in student.keys():
    print(f"{student[k]}") #print the value of the key k
print("")

# another way to access dictionary values
for v in student.values():
    print(f"{v}")
print("")
