# a list of dictionaries which nest a list
students = []
students.append({'name': 'Luis','grades': [76,83,91]})
students.append({'name': 'Lia','grades': [85,37,76]})
students.append({'name': 'Sarah','grades': [85,37,76]})
print(students)
# print a list of dictionaries
for s in students:    # students is a list with 3 elements
    print(s)
print("")

# nested loop
for s in students:                      # loop to iterate through each student
    print(f"{s['name']:8}: ", end=" ")  # print each students name
    for g in s['grades']:               # nested loop to iterate through each grade
        print(g, end=" ")
    print("")                           # new line for each student output
print("")
