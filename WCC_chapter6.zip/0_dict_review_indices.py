#Let's review what we know

#We can use indexes to access List and string elements.
toDoList=['feedTheDog','walkTheDog', 'gradeExams', 'checkEmail',]
print(toDoList[2])
aTaleofTwoCities ='It was the best of times, it was the worst of times.'
print(aTaleofTwoCities)
print(aTaleofTwoCities[0], end=" ")
print(aTaleofTwoCities[2], end=" ")
print(aTaleofTwoCities[3], end=" ")
print(aTaleofTwoCities[-1])
# dictionaries are not indexable in this way
student_33 ={'name':"Jen", 'age':36, 'country':"Norway"}
student_33= dict(name = "Jen", age = 36, country = "Norway")
print(student_33)
#print(student_33[0])     #key error
print(student_33[1])     #key error
# dictionary[0] only works in the event that 0 happens to be a key
