# dictionary keys are more flexible then list indexes

# keys can be numbers
myGrades = {10: 'John', 9: 'Jane', 11: 'Jim'}
print(myGrades[11])
print(myGrades[10])
print(myGrades[9])
print("")

# keys can be strings
student = {'name': 'John', 'major': 'CSIS'}
print(student['name'])
print(student['major'])
print(student)
print("")
#pythoDictionary = {key1:value1, key2:value2, key3:value3}
#This pythonDictionary contains 3 items.