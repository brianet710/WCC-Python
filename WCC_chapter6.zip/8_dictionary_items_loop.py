#Dictionary items() method
# Retrieve both the key and value.

student = {
    'name':'Taylor','major':'Music','age':30,'id':407711
}
print(student)
print("")

# access directionary keys and values using a loop
for k, v in student.items():
    print(f"{k} - {v}")
print("")
