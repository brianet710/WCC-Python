# dictionary values can be of any simple type

# values can be numbers
myGrades = {'quiz1': 95.5, 'quiz2': 80, 'quiz3': 87}
print(myGrades)
print("")

# values can be strings
student = {'name': 'John', 'major': 'CSIS'}
print(student)
print("")

# values can be bools
student = {'isEnrolled': True, 'billPaid': False}
print(student)
print("")

# values can be of mixed types
person = {'name': 'Bob', 'age': 41, 'isEmployed': True }
print(person)
print("")
