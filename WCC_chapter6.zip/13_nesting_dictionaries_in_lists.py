# nesting dictionaries in lists
#create 3 dicts
s1 = { 'name': 'John','gpa': 3.5 }
s2 = { 'name': 'Kim','gpa': 2.8 }
s3 = { 'name': 'Anna','gpa': 3.7 }

# nest the dictionaries into a list
students = [s1, s2, s3] #the list elements are dicts

# print each dictionary by looping through lists
for s in students:
    print(s)
print("")

# initialize a multiple person dictionaries and store in a list
persons = []
for p in range(51):
    person = {'name': 'default', 'school': 'WCC' }
    persons.append(person)

# print the first three persons
for p in persons[0:3]:
    print(p)
print("")
