#update allows multiple items to be added

my_dictionary = {'a': 1, 'b': 2, 'c': 3}

# Append new key-value pairs using update()
my_dictionary.update({'d': 4, 'e': 5})

print(my_dictionary)

your_dictionary = {'y':25, 'z':26}

#update my_dictionary with items from your_dictionary
my_dictionary.update(your_dictionary)
print(my_dictionary)