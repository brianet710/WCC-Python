''' Dictionaries are composed of key-value pairs
keys - the location of information in a dictionary, similar to a list index
values - the data that associated with a specific key
keys must be unique within a dictionary. Values may repeat.
A dictionary is an associative array, where arbitrary keys are mapped to values.
'''
# keys in this example are the strings Lehman, QCC and BMCC
# values in this example are 'John', 'Jane' and 'Jim'
# This dict has 3 items
mySchool={'Lehman': 'John', 'WCC': 'Jane', 'BMCC': 'Jim'}

# A representative from each school is attending a meeting
# values may be accessed by their keys
print(mySchool['BMCC'])
print(mySchool['Lehman'])
print(mySchool['WCC'])

print("")
'''
Unlike lists and strings which are iterables that support
element access using integer indices, dictionaries are 
indexed by keys.
'''