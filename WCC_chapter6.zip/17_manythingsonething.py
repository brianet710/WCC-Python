# A dictionary (mapping) of multiple similar objects:
python_vocabulary = {
'loop': 'repeated action',
'list': 'ordered collection',
'dictionary': 'keys and values',
}
# In above example, every key represents a term,
# and every value represents a definition.
# -------------------------------------------

#A dictionary representing only one very specific thing:
fleet_vehicle_011 = {
'make': 'subaru',
'model': 'crosstrek',
'year': '2023',
'lease_end': '2025.09.25',
'status': 'available',
}
print("Above are 2 example use cases for Python dictionaries (mappings)")
