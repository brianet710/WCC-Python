#setdefault adds an item if key does not exist.
#An existing item will not be overwritten

club_members = {1201: 'sue', 911: 'bill', 883: 'sam'}

# Append a new key-value pair using setdefault()
club_members.setdefault(1199, 'jan')
#club_members.setdefault(911, 'jon')

print(club_members)

