# create a dictionary
student = {
    'name': 'John',
    'major': 'History',
    'age': 25,
    'id': 606123
}
print(student)
print("")

# remove some data from the dictionary
del student['age']
del student['major']
# note that key:value pairs were removed simultaneously
print(student)
print("")
