# create a dictionary
student = {'name': 'John', 'major': 'History'}
print(student)
print("")

# modify dictionary values using assignment operator
print (student['name']) # this refererences the value associated with the key 'name'
student['name'] = 'Bob' # Bob replaces John
print(student)
print("")

student['major'] = 'English'
print(student)
print("")
