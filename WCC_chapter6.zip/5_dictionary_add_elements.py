# create an empty dictionary
student = {}
print(student)
print("")

# add some more data to the dictionary
student['name'] = 'Emily'
student['major'] = 'Nursing'
student['age'] = 20
student['id'] = 504680

print(student)
print("")
