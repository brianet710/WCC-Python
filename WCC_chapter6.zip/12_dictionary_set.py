'''
A set is used to represent the collection of elements
without duplicates. It is enclosed by the {} and each
element is comma separated. There is no colon.
'''
students = {
    'John': 'ET580',
    'Jake': 'ET575',
    'Jane': 'ET575',
    'Jim':  'ET574',
    'Jule': 'ET580',
    'Jack': 'ET575',
    'Joan': 'ET575',
}
print(students)
print("")

# this prints a repetitive list due to duplicate values
for v in students.values():
    print(v, end=", ")
print("")

# set function returns the list of values without duplicates
for v in set(students.values()):
    print(v, end=", ")
print("")

unique = set(students.values())
print(type(unique))  # unique is NOT a dictionary
