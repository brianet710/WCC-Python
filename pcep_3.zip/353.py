'''
The None keyword designates:

A. A function which does not have a value
B. An empty instruction
C. a None value
D, a non-numeric value

'''

#print( 0 == None)
#print(False == None)
#print(False == 0)