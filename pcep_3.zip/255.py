'''
What is the output?

'''
def fun(test_string):
    for i in test_string:
        if i == "duck":
            yield i

test_string = """if it looks like a duck and swims like a duck,
and quacks like a duck"""

test_string = test_string.split()
count = 0

for j in fun(test_string):
    count = count + 1

print (count)    
'''
A. a runtime error
B. 3
C. 1
D. 0

# The word duck happens twice.
# duck, is a word


'''