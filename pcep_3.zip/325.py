'''
Which statement is correct?

A. 
Bitwise AND operator returns 1 only if both bits are 1, else it returns 0

B.
Bitwise OR operator returns 0 only if both bits are 0.
 
C.
Bitwise XOR operator returns 0 if both bits are the same (either 0 or 1).

D.
All of the above.


# https://www.w3schools.com/python/python_operators.asp
'''