# How many stars will be sent to the console?

i = 4
while i > 0:
    print('*')
    i -= 2

'''
A: one
B. two
C. three
D. four
'''    