'''
The following expression is equal to:
'''
x = 10 // 2 * 3
print(x)
'''
A. 0.0
B. 1
C. 15.0
D. 15
'''
''''''
x = 10 //2 ** 3
print(x)

# Integer/floor division retunrs and integer
# Exponentiation follows right-side binding
'''