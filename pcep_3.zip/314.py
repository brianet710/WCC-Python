'''
The result of the following addition
var = 321 + 0.0

A. is equal to 321
B. cannot be evaluated
C. is equal to 321.0
D. is equal to 0.321
'''