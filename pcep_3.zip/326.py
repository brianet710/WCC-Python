'''
What is the output when the user enters 3.14and 1.0 respectively
'''
pi= float(input())
rad = int(input())

area = pi * rad ** 2
print(area)
'''

A. ValueError invalid literal for int() with base 10: '1.0'list
B. 3.14
C. 3.141.0
D. 3    
'''


'''
x = float("1.0")
x = int(x)
print(x)
'''