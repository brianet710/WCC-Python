'''
What is the output?
'''

result = True > False or False < True
print(result)

