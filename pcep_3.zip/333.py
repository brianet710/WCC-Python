# What is the output?

i = 1
while i >4:
    i += 1
    print("Hi")
else:
    i -= 1
    print("Ho")

'''
A. Hi
B. Ho
C. runtime error
D. 0
'''        