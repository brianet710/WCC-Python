# What is the output? Note 10. is identical to 10.0. Both are floats
x = 10.
def fun():
    global x
    x =20.
    print(x, end=' ')

x = 30.
fun()
print(x)

'''
A. 30.0 30.0
B. 20.0 30.0
C. 20.0 20.0
D. 30.0 20.0
'''

# global scope means that var x  inside the function
# and var x outside the function are references to the same value in memory
# print(id(x))
#  