'''
The advantages of interpreted languages are that
(select TWO answers):

A. A user can run the code immediately.
B. The execution of the code is usually faster.
C. The code is stored using a programming language.
D. The code is stored using machine language.
'''