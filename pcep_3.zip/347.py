# What happens when the following code is run?

my_tup = 'a', 'b', 'c', 'd'
print(my_tup[-1])

'''
A. -1 will be printed
B. d will be printed
C. The code is erroneous
D. The program will print (.) to the screen
'''