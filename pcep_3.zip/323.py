'''
What is the output?
'''
x, y, z = 5, 0b1010, 8
print(x > z, end = ' ')
print((y - 5) == x)
'''
A. False True
B. False False
C. True True
D. True 1
'''