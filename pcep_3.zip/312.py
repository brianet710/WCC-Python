'''
What is the output?

print("Good morning", "\nHoney!")

A. 
Good Morning Honey!
B. 
Good morning
Honey!
C.
Good Morning"
nHoney!"
D.
Good Morning
nHoney!
   

'''