# What is the output?

def myFunc():
  yield "Hello"
  yield 51
  yield "Good Bye"
  
x = myFunc()
  
for z in x:
  print(z, end = ' ')

'''
A. Hello 51 Good Bye
B. Hello
C. Good Bye
D. illegal code
'''
# Yield returns an iterable (we can loop through it)
# https://www.w3schools.com/python/ref_keyword_yield.asp            

