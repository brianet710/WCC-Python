'''
One of the Python drawbacks is that:

A.  The full version is not free
B.  It is difficult to learn.
C.  It is not super fast
D.  It is complicated to install

'''