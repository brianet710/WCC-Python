# Choose the one statement which is true:

list1 = []
list2 = list1[:]
list2.append(0)

'''
A. list2 is longer than list1
B. list1 is longer than list2
C. list1 and list2 are the same length
D. list1 and list2 are references to the same list in memory
'''