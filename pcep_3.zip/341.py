#Select all statements which are correct
'''
A. The indentation in Python is mandatory.
B. The # is used for single line comments. Triple quotes are used for multiline comments.
C. We don't need to declare the type of a variable in Python
D. Python is first interpreted, then compiled when you run it




'''