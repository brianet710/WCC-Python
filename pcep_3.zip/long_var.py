long_var = " if it looks like a duck and quacks \
like a duck and swims like a duck \
and tastes like a duck "

print(long_var)