# What is the output?
dictionary1 = {1:2, 3:1, 2:3}
item = dictionary1[1]
for i in range(len(dictionary1)):
    item = dictionary1[item]
print(item)
'''
A. 1
B. [1,2,3]
C. 2
D. 3
'''
#line 3 item = 2
#Loop 1 item = 3
#Loop 2: item = 1
#Loop 3: item = 2