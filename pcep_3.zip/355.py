# What is the output?

def myfunc(num):
    if num == 1:
        print('I am 1')
        return True
    print('Im here', num) 
    return myfunc(num -1) * num
    
print(myfunc(3))

'''
A. 10
B. None
C. 6
D. True
'''

#recursion: when a function calls itself
# (3 minus one) * 3

# https://www.youtube.com/watch?v=YZcO_jRhvxs