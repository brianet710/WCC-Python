# What is the output?
def fun(test_string):
    for i in test_string:
        if i == "duck":
            yield i

test_string = '''If it looks like a duck swims like a duck\
                and quacks like a duck ...'''            
test_string = test_string.split()
print (test_string)
count = 0
for j in fun(test_string):
    count = count +1 #track how many times we loop
print(count)    
'''
A. 3
B. 2
C. 1
D. 0
'''
# we can think of yield as something which returns a list
