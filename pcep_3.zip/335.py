# What is the output?

for i in range(0,10,14):
    print("The current value of i is", i)

'''
A. 0
B. 0 10
C  0 14
D  0 10 14
'''    
          