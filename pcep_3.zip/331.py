'''
What is the output?
'''
grades = 95
if grades > 90 and grades <= 100:
    print("Excellent")
elif grades > 80 and grades <= 90:    
    print("Very Good")
elif grades > 70 and grades <= 80:    
    print("Good")
else:
    print("Satisfactory")
        