# What is the output?

my_list = [10, 8, 6, 4, 2]
del my_list[1:3]
print(my_list)

'''
A. [1, 2, 3]
B. [10, 8, 6]
C. [10, 4, 2]
D. [10, 2]

'''