'''
What is the output is the user enters two lines
containing x and y respectively?
'''
x = input()
y = input()

print(x + y)

'''
A. x and y
B. x + y
C. xy
D. x y

'''