# What is the output?

drinks = ("Manhattan", "Martini", "French 75", "Screwdriver")
i, j, k, l = drinks
#(i, j, k, l) = drinks

print(k)

#unpacked and assigned to vars
# https://www.w3schools.com/python/python_tuples_unpack.asp

