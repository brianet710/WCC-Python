# What will be the output? Hint: nums is a list of lists

nums = [[1, 2, 3]]
initializer = 1
for i in range(1):
    initializer *= 5
    for j in range(1):
        nums[i][j] *= initializer
print(nums)
'''
A. [[5]]
B. [[1, 2,3]]
C. [[5, 1, 2, 3]]
D. [[5, 2, 3]]
'''

