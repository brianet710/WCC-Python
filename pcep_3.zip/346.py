# What is the output?

num3 = [num ** 3 for num in range(5)]
print(num3)

'''
A. [0, 5, 10, 15, 20]
B. SyntaxError
C. [0, 3, 6, 9, 12]
D. [0, 1, 8, 27, 64]
'''