# What is the output?
x = 10
y = 10.0
z = "10"

if x == y:
    print("one", end=' ')
if y == int(z):
    print("two", end=' ')    
elif x == y:
    print("three", end=' ')    
else:
    print("four", end=' ')    

'''
A. one two
B. one three
C. one four
D. 1 2
'''
'''
print()
var_a = 5  # int
var_b = 5.0  # float
print(x == y)   #this is a value comparison

var_c = 6  # int
var_d = 6.0  # float

print(type(x) == type(y)) # this is a type comparison
'''