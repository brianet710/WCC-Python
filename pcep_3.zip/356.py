# What is the output? Hint: There are 2 print statements

def prices(param1, param2, *prices):
    print(param2, end = ' ')

print(prices('Hotel', 'Quirk', [33,34,70]))

'''
A. Quirk None
B. 33 34 70
C. Quirk
D. 'Hotel', 'Quirk', [33,34,70]'''

#What is returned from the function to line 6?