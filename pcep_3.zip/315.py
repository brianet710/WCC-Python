'''
A complete set of known commands that a particular
computer processor understsands and executes is called:

A. An instruction set.
B. A low-level list
C. A basic list
D. A logic list


'''