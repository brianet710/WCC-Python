# Styling our Plots
# https://matplotlib.org/tutorials/introductory/usage.html#sphx-glr-tutorials-introductory-usage-py
# https://matplotlib.org/3.2.1/api/_as_gen/matplotlib.pyplot.plot.html
# https://matplotlib.org/3.2.1/api/markers_api.html#module-matplotlib.markers
import matplotlib.pyplot as plt

numbers= [1,2,3,4,5]
squares = [1,4,9,16,25]
cubes = [1,8,27,64,125]

# print a list of figure styles
print(plt.style.available)
plt.style.use('grayscale')

fig,ax = plt.subplots()
# style the plot
ax.plot(numbers, squares, label='squares')
ax.plot(numbers, cubes, label='cubes')

ax.set_title('Numbers Squared')
ax.set_xlabel('Numbers')
ax.set_ylabel('Squares')

ax.tick_params(axis='both')

ax.legend(loc='best')
plt.show()
