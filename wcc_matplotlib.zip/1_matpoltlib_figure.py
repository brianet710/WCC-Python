'''
Data Visualization: Matplotlib is a graph plotting library.
Matplotlib produces publication-quality figures in a variety of 
hardcopy formats and interactive environments across platforms.
'''
# We can think of a figure as an empty canvas
# https://matplotlib.org/tutorials/introductory/usage.html#sphx-glr-tutorials-introductory-usage-py

#The pyplot submodule is the one most often used.
import matplotlib.pyplot as plt

# a Figure is the space upon which a graph can be placed
fig = plt.figure()                  # create an empty figure
fig = plt.figure(figsize=(10,5))    # create an empty figure which is 10 by by 5 inches
plt.show()                          # show the figure

'''
Citing Matplotlib
If Matplotlib contributes to a project that leads to a scientific
publication, please acknowledge this fact by citing J. D. Hunter, 
"Matplotlib: A 2D Graphics Environment", Computing in Science & 
Engineering, vol. 9, no. 3, pp. 90-95, 2007.
'''
#Remember to close the figure between running the examples.
