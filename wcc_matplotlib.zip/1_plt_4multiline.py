import matplotlib.pyplot as plt
import numpy as np
#Plot as many lines as you need

x1 = np.array([0, 1, 2, 3])
y1 = np.array([2, 9, 3, 10])
y2 = np.array([5, 1, 9, 11])

plt.plot(x1, y1)
plt.plot(y2)

plt.show()

#Another wat to plot 2 linesx1 = np.array([0, 1, 2, 3])
y1 = np.array([3, 8, 1, 10])
x2 = np.array([0, 1, 2, 3])
y2 = np.array([6, 2, 7, 11])

plt.plot(x1, y1, 'o-b', x2, y2, '^-r')
plt.show()
