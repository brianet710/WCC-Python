import matplotlib.pyplot as plt
import numpy as np

xpoints = np.array([0, 6])
ypoints = np.array([0, 250])
'''
plot() By default, draws a line between points.
The x-axis is horizontal, the y-axis is vertical.
plot(x-axis points, y-axis points)
'''
plt.plot(xpoints, ypoints)
#plt.plot(xpoints, ypoints, 'o') #markers only, no line
plt.show()

#2 Points (0,0 & 6,250)
'''
You can hover your mouse on the line to read the x/y values.
You can resize the figure.
You can save the figure as an image file.
''' 
