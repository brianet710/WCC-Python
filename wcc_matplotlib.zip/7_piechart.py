# Use a pie chart to represent how each part contributes to the whole
import matplotlib.pyplot as plt
import numpy as np

y = np.array([35, 25, 25, 15])
mylabels = ["401k", "soc_sec", "pension", "pt_work"]
myexplode = [0.1, 0, 0, 0]

plt.pie(y, labels = mylabels, explode = myexplode, shadow = True)
plt.show()
