 # A Line plot
#  
# https://matplotlib.org/tutorials/introductory/usage.html#sphx-glr-tutorials-introductory-usage-py
import matplotlib.pyplot as plt

x = [1,2,3,4,5]
y = [1,4,9,16,25]

fig,ax = plt.subplots()
ax.plot(x,y)                        # create a plot of x and y axis values
ax.set_title('Numbers Squared')     # set a title
ax.set_xlabel('Numbers')            # name the x-axis
ax.set_ylabel('Squares')            # name the y-axis
plt.show()
#fig.savefig('numbersSquared.png')

'''
About Line 9 -
plt.subplots() is a function that returns a tuple containing a
figure and axes object(s). When using fig, ax = plt.subplots()
you unpack this tuple into the variables fig and ax. 
Having fig allows us to save an image file with savefig().
'''