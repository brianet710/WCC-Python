#Use  the marker parameter to emphasize each point.
import matplotlib.pyplot as plt
import numpy as np

ypoints = np.array([3, 8, 1, 10])
#marker appearance and size
plt.plot(ypoints, marker = 'o', ms=15) #round size 15
plt.show()

# https://matplotlib.org/stable/api/markers_api.html#module-matplotlib.markers


#xpoints defaults to [0, 1, 2, 3]
ypoints = np.array([3, 8, 1, 10])
#MarkerShapeLineTypeColor
plt.plot(ypoints, '^--r')   #Up Marker dashed red 
plt.show()

# https://www.w3schools.com/python/matplotlib_markers.asp
