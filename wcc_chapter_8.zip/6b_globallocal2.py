'''variable scope local vs global
If you create a variable with the same name inside a function,
this variable will be local, and can only be used inside the function.
The global variable with the same name will remain as it was, global and with the original value.
'''
x = "awesome"   # x is a global var

def myfunc():
  x = "fantastic"  # x is a local var
  print("Python is " + x)

myfunc()   # call the function with no arguments

print("Python is " + x)  # Outside of the function we reference the global x

# https://www.w3schools.com/python/python_variables_global.asp
#https://www.python-course.eu/python3_global_vs_local_variables.php
