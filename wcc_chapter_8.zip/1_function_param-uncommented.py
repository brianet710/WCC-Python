#function with parameters

def greet(name):
    """This function greets the user."""

    print("Hello, " + name + "!")


#functions with parameters are called with arguments
greet("Alice")
greet("Bob")
#greet()