print("Question #1")
n = 0
while n in range(0,55):
    print(n, end = " ")
    n+=5
    

print("\nQuestion #2")
grades = []
gpa = 0
count = 0 
while True: 
    grade = input("Enter a grade or -1 to stop: ")
    if grade == "-1":
        break
    grade = int(grade)
    grades.append(grade)
    gpa += grade 
    count +=1
    
if count > 0:
    total = gpa / count
    print("The GPA is {:.0f}".format(total))


print("\nQuestion #3")
grades = [96,34,67,88,90]

number = 0
while number < len(grades):
    if grades[number] < 64:
        del grades[number]
    else:
        number += 1

for grade in grades:
    print(grade, end=" ")

print("")
print("\nQuestion #4")


last_months = ['July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
label = 7  

for counter, month in enumerate(last_months):
    print(f"{counter + label} {month}", end=", ")
    
    
print("")
print("\nQuestion #4")  
 
toppings = []
ticket_cost = 0

print("~~~~~ Welcome to Pizza and a Movie ~~~~~")
while True:
    pizza_topping = input("What topping would you like on your pizza (type 'quit' when done)?\n")
    if pizza_topping.lower() == 'quit':
        break
    toppings.append(pizza_topping)
    
age = int(input("Hold old are you?\n"))

if age <= 3:
    ticket_cost = 0
elif 4<= age <= 12:
    ticket_cost = 10
else:
    ticket_cost = 12


print("Your pizza toppings will be: " + ", ".join(toppings))
print(f"Your movie ticket cost: ${ticket_cost}.")
print("--------------- End ------------------------ ")
