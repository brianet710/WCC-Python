# Import all code from the file math_funcs.py.
# Create an alias mf for math_funcs.
import math_funcs as mf

# Call the add function using the mf alias.
answer = mf.add(5,4,3,2,1)
print(answer)

# Call the multiply function using the mf alias.
print( mf.multiply(5,4,3,2,1) )

print("")
