'''
To change the value of a global variable inside a function, 
refer to the variable by using the global keyword:
'''
x = "awesome"

def myfunc():
  global x    # this references the global x
  x = "fantastic"   # 'awesome' gets replaced with 'fantastic'


#main
print(f"python is {x}")   #print x before the function is called
myfunc()
print("Python is " + x)

print()

#Remember: the function only executes when called.
