'''
Any data type may be an argument to a function.
It will be treated as the same data type inside the function.
'''
def output(anything):
    """Print the text specified by parameter"""
    print(anything) #sometext stores the argument sent during the function call
    #print(type(anything)) 

# Call the output function using different types of arguments

output("How are you?")
output(95)
output(2.5)
output(False)
fruits = ["apple", "banana", "cherry"]
output(fruits)
holidays={'New Years Day':'Jan 1', 'MLK Day':'Jan 17', 'Independence Day':'July 4'}
output(holidays)
print()
'''
Passing arguments to parameters have the effect of assignment statements.
anything = "How are you"
anything = 95
anything = 2.5
anything = ["apple", "banana", "cherry"]
anything = {'New Years Day':'Jan 1', 'MLK Day':'Jan 17', 'Independence Day':'July 4'}
Python is dynamically typed
'''