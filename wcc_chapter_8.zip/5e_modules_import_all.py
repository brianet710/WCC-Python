# Import all functions of a module and use them by name.
# This is not recommended.
from math_funcs import *

# Call the add function without the math_funcs_funcs prefix.
answer = add(5,4,3,2,1)
print(answer)

# Call the multiply function without the math_funcs_funcs prefix.
print( multiply(5,4,3,2,1) )

print("")
