'''
A function is a code block which runs when called.
A function name generally suggests an action.
Function names should be lowercase, with words separated by underscores as necessary.

'''
def greeting():
    """This function prints hello.""" # docstring describes what the function does
    print("Hello. I am the greeting function")

# "Call" to execute the function (run the code inside the function)
greeting()
print("")

# Call the same function multiple times
# Code inside a function is reusable code
#
greeting()
print('Other interesting Python code could be here')
greeting()
print("")

'''
After execution of a function's code block,
program execution continues with the statement
following the function call.
'''
