# module.py

def calculate_sum(a, b):
    return a + b

def main():
    x = 5
    y = 10
    result = calculate_sum(x, y)
    print(f"The sum of {x} and {y} is {result}")

if __name__ == "__main__":
    main()