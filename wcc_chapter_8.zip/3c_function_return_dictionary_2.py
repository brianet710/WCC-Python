# Define a function that takes keys and values
# which are used to create and return a dictionary.
# The **info parameter builds a dictionary from the user arguments.
def printUser(**info):
    return info   #ends the function
    #print("Why don't I print?")

user1 = printUser(name='John', GPA='3.53', major='English', school='WCC')

#print(type(user1))

for k,v in user1.items(): # output the new dictionary keys and values
    print(f"{k}: {v}")

print()
