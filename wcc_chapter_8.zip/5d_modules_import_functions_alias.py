# Import specific functions from the file math_funcs_funcs.py,
# and give those functions Aliases, or alternate names.
from math_funcs import add as a
from math_funcs import multiply as m

# Call the add function using its Alias name.
answer = a(5,4,3,2,1)
print(answer)

# Call the multiply function using its Alias name.
print( m(5,4,3,2,1) )

print("")
