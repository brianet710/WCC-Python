'''
This module provides functions for mathematical operations
'''


# Define a function to sum all argument values.
def add(*values):
    answer=0
    for v in values:
        answer+=v
    return answer

# Define a function to multiply all argument values.
def multiply(*values):
    answer=1
    for v in values:
        answer*=v
    return answer
# Note: run this py file to confirm absence of output.
# All statements are legal python statements. Why no output?

'''
Modules can be imported by many different program
WORM write once read many
code reusability
'''