'''
Variables that are created outside of a function are known as global variables.
Global variables can be used by everyone, both inside of functions and outside. 
vars declared inside of functions are only accessible within the function. They are local. '''
message =''
def motd():
  global message 
  message = "Plan A didn't work. Not to worry. There are 25 more letters"
  lvar = "hi"
# main
motd()
print (message)    
#print (lvar)  #lvar is not defined outside the scope of the function