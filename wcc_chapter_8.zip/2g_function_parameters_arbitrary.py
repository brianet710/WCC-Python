# Define a function with an Arbitrary number of parameters
# The *grade parameter builds a Tuple of the submitted arguments.
# Recall that a Tuple is immutable, read-only.
# We use a loop to output all elements of the Tuple
def print_grades(*grade):
    '''prints grades: each separated by a space'''
    
    for g in grade: # print all contents of the tuple
        print(g, end=" ")

# Call the function with two grade arguments
print_grades(76,88)
print("")

# Call the function with five grade arguments
print_grades(100,98,74,87,53)
print("")

#The * character is what identifies the parameter as arbitrary
