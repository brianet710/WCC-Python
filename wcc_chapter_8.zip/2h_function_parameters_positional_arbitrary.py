# Define a function with Positional and Arbitrary parameters.
def print_grades(name, school, *grade, ):
    print(name)
    print(school)
    for g in grade: # print all contents of the tuple
        print(g, end=" ")

# Call the function with two grade arguments
print_grades('Ishmael', 'wcc', 50, 30,60, 99)
print("")

