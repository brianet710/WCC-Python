''' Declare a function with a single parameter
    A parameter is a variable that stores information which is
    passed to the function when it is called. '''

def output(sometext):
    """Print the text specified by parameter"""
    print(sometext) #sometext stores the argument sent during the function call
    #print(type(sometext))

'''Call the output function with an argument.
   An "argument" is the data that is sent to a function parameter.
  '''

output("Hi.")

''' Call the output function and each time assign the
    argument to the parameter variable "sometext".
    What we pass in the function call is an argument.
    Inside the function this argument is called a parameter.
    Below are 4 function calls '''

output("How are you?")
output(95)
output(2.5)
output(False)

# Unlike input(), parameters are stored as the type passed to them
# a primary purpose of a function is code reusability

