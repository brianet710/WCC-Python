# Define a function with two parameters
# This function has two parameters separated by a comma.
def print_person(name, age):
    print(f"Hi {name} your age is {age}.")

# Positional Arguments
# Argument order must match parameter order.
# Every previous example has also used positional parameters/arguments.
print_person("John", 5)

# Positional Arguments
# Arguement order must match parameter order.
# Note that the output for this is wrong,
# because the order doesnt match the parameter order.
print_person(9, "June")

print("")
