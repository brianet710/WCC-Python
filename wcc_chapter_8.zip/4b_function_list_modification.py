# 2 functions at work
# Define a function to modify a list
def add_grade(grades):
    """Append a grade of 100 to grades."""
    grades.append(100)

# Define a function to print a list
def print_list(grades):
    for g in grades:
        print(g, end=" ")

# main
antons_grades = [90,75,80,70]
add_grade(antons_grades) #call the function with an empty list
print_list(antons_grades)
