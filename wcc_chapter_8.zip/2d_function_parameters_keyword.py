#Keyword Arguments Kwargs

# Define a function with two parameters
# This function has two parameters separated by a comma.
def print_person(name, age):
    print(f"Hi {name} your age is {age}.")

# Argument order does not matter because the parameter is specified.
print_person(name="John", age=5)

# Keyword Arguments
# Argument order does not matter because the parameter is specified.
print_person(age=9, name="June")

print("")
