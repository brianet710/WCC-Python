# Functions may return dictionaries
# Return a dictionary created from the parameter values.
def getPerson(name, age):
    person = {'name': name, 'age': age}    #build a dictionary from provided arguments
    return person

# Call the function with two arguments, return a dictionary.
p = getPerson("John", 10)
print(p['name'])
print(p['age'])
print(p)
print("")
