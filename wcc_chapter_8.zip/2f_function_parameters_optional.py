# Define a function with three parameters
# This function has two required parameters and one default parameter.

#This function may be called with 2 or 3 arguments.
def print_person(name, age, job=""):
    if job:
        print(f"Hi {name} your age is {age} and your profession is {job}.")
    else:
        print(f"Hi {name} your age is {age}.")

# Call the function with only the first two parameters.
print_person("John", 45)

# Call the function with an argument for the third parameter.
print_person("John", 45, "Programmer")

print("")
