''' About the classical main() function as applies to python

https://www.freecodecamp.org/news/if-name-main-python-example/

 __name__ is a special variable (dunder)

The __name__ variable will be set as  __main__ if the module
that is being run is the main program (every program we have written).

The __name__ variable for all modules that are being imported
will be set to their module's name.


if __name__ == '__main__':
    print('I am the main program')
'''
#This file has no output; it is only comments.
#if __name__ == '__main__':
#    print('I am the main program')