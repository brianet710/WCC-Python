# Import all code from the file math_funcs_funcs.py and place it here.
import math_funcs

# Call the add function defined in the file math_funcs_funcs.py.
# Store the return value, then print it.
# To call these functions, we use module-name.function-name()
answer = math_funcs.add(5,4,3,2,1)
print(answer)

# Call the multiply function defined in the file math_funcs_funcs.py.
# Print out the return value directly.
print( math_funcs.multiply(5,4,3,2,1) )

print("")



# The list of built in modules. All included when python is installed
import sys
print(sys.builtin_module_names)
print()
print(sys.path)
#  Python prioritizes local modules over built-in modules with the same name. 
math_funcs.str(5)
