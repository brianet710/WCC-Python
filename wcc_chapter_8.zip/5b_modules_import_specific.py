# Import specific functions from the file math_funcs_funcs.py
from math_funcs import add, multiply

# With specific import, the math_funcs_funcs.prefix is no longer needed
# for function calls (see 5a_modules_import for comparison)
answer = add(5,4,3,2,1)
print(answer)

print( multiply(5,4,3,2,1) )

print("")

mystring = str(99)
#print(mystring)
print(type(mystring))
#built-ins. Avoid using these same names in your functions
#https://docs.python.org/3/library/functions.html