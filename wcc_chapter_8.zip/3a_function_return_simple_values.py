# functions may return values
# Define a function with two parameters
def add(a, b):
    """Returns the sum of two values"""
    #print("I can both do stuff and return stuff")
    return a+b  #return means to give back to the calling statement

# Call the function and print its return value.
print(add(5, 7))

# Call the function and store its return value into a variable. Print the variable.
s = add(10,15)
print(s)

print("")
# An incorrect way to call this function which has a return value
#add(33,22)