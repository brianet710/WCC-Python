'''
Lets revisit built in functions we've used before.
Many but not all return values
'''

myCash = [50,20,35,75,40]
howMuch = sum(myCash)  #storing a return value in a var
print(howMuch)
print(sum(myCash))      #printing a return value  
print(max(myCash))      #printing another return value

# When sorted() is called, it provides a
# list as a return value
mySortedCash = sorted(myCash)   #storing a return value in a var
print(mySortedCash)


#sort() provides no return value. It modifies a list and returns nothing
myCoins = [5,25,100,50,1]
mySortedCoins = myCoins.sort()
print(mySortedCoins) #None

itemZero = del myCash[0] #del provides no return value. This will produce an error
