# Define a function with a list as a parameter
def hello(students):
    """Print hello to each student"""
    for s in students:
        print(f"Hello {s}")

# Sending a list to a function
students = ['Andy', 'Bob', 'Cherrise', 'David']
hello(students)

#hello('Natalya') # what will this do?

print("")

#Unlike tuple & dictionary parameters, list parameters are determined solely by the calling arguments.