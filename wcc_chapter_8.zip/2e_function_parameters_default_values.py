# Default parameter values
# This function has two parameters separated by a comma.
# Note that values are assigned in the function definition
def print_person(name="noname", score=0):
    print(f"Hi {name}. Your score is {score}.")

# A function can be called without arguments because default parameter values are used.
print_person()

# A function can be called with some arguments because default parameter values are used.
# This uses a positional argument which assumes the argument is for the first parameter.
print_person("John")

# A function can be called with some arguments because default parameter values are used.
# This uses a keyword argument which clarifies that "John" is for the "name" parameter.
print_person(name="John")

# A function can be called with some arguments because default parameter values are used.
# This uses a keyword argument which clarifies that 10 is for the "score" parameter.
print_person(score=10)

# A function can be called with all arguments ignores the default parameter values.
print_person("John", 5)

print("")
