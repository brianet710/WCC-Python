# functions may have multiple parameters
# parameters are separated by commas.
def sum_and_print(a, b):
    """Add the value of two parameters"""
    print(a+b)

# Call the function with two string arguments.
sum_and_print('hi', 'you')

# Call the function with two integer arguments.
sum_and_print(10,15)

# Call the function with one argument (generates an error).
# The number of arguments must match the number of parameters.
# Enable the next line of code to see the error.
#sum_and_print('a','b', 'c')

print("")
