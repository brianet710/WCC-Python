#Note: the main function inside module.py does not run
import module

print(module.calculate_sum(1, 2))
    

