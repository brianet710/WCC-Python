# Define a function with Keyword and Arbitrary parameters.
# The **info parameter builds a dictionary from the user arguments.
def print_user(name, **info):
    print(name)
    for v in info.values():
        print(v, end=" ")

# Call the function with three keyword arguments.
print_user(name='John', age='54', job='Programmer')
print("\n")

# Call the function with four keyword arguments.
# Note that John goes to the name parameter and not the dictionary.
print_user(GPA='3.53', major='English', school='QCC', name='John')
print("\n")

#The ** characters is what identifies the parameter as a dictionary