import matplotlib.pyplot as plt
import numpy as np

Education= ['< HS', 'HS Grad', 'Some College', 'Bachelors', 'Graduate']
Earnings= [1.13, 1.54, 1.76, 2.43, 3.05]
plt.barh(Education, Earnings, .5, align ='center')
plt.suptitle('Lifetime Gross Earnings (in $millions)')
plt.show()