import json, requests

def get_movie_info(title):
    url = f"http://www.omdbapi.com/?t={title}&apikey=ae69ad4c"

    response = requests.get(url)
    data = response.json()

    if data['Response'] == 'True':
        movie_title = data['Title']
        year = data['Year']
        genre = data['Genre']
        plot = data['Plot']
        rating = data['imdbRating']
        print(f"Title: {movie_title}")
        print(f"Year: {year}")
        print(f"Genre: {genre}")
        print(f"Plot: {plot}")
        print(f"IMDB Rating: {rating}")
    else:
        print("Movie not found!")

while True:
    movie_title = input("Enter a movie title (or 'quit' to exit): ")

    if movie_title.lower() == "quit":
        break

    get_movie_info(movie_title)