import json
import requests
print()
print("--- World Weather at your Service ---")
#openweather api key is e93853c7f8ed39efa4533bbea32f23ca
while True:
    cityname = input("Enter city name:")
    cityname.replace(" ","+")
    if cityname == "quit":
        print("Bye. See you next time")
        break
    else:
        weatherurl = "http://api.openweathermap.org/data/2.5/weather?appid=e93853c7f8ed39efa4533bbea32f23ca&q=" + cityname + "&units=imperial"
        weatherresponse = requests.get(weatherurl)
        doescityexist = weatherresponse.json()
        if doescityexist["cod"] == "404":
            print("city not found, try again")
        else:
            cityweather = doescityexist["main"]
            print(f"Temperature (in fahrenheit) = " + str(cityweather["temp"]))
            print(f"atmospheric pressure (in hPa unit) = " + str(cityweather["pressure"]))
            print(f"humidity (in percentage) = " + str(cityweather["humidity"]))
            print(f"description = " + str(doescityexist["weather"][0]["description"]))
            print()