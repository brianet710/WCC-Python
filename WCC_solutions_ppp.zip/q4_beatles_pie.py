import matplotlib

import matplotlib.pyplot as plt
import numpy as np

y = np.array([28, 26, 25, 21])
mylabels = ["John", "Paul", "George", "Ringo"]
myexplode = [0.1, 0, 0, 0]
plt.suptitle("Who's your Favorite Beatle?")
plt.pie(y, labels = mylabels, explode = myexplode, shadow = True,  autopct='%1.1f%%')
plt.show()
