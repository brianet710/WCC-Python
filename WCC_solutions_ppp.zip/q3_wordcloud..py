from wordcloud import WordCloud
import matplotlib.pyplot as plt
import csv
file_d = open("sample.csv") 
reader_d = csv.reader(file_d)
reader_contents = list(reader_d)
words = ""
 
for row in reader_contents :     
    for word in row :
        words = words + " " + word

wordcloud = WordCloud(width=480, height=480, max_words=10).generate(words)
 
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.margins(x=0, y=0)
plt.show()