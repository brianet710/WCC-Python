# bar graph
# numpy arrays are similar to python lists
import numpy as np
import plotly.graph_objects as go

# numpy one dimensional arrays
numbers = np.arange(1,21)
#numbers = [n for n in range(1,21)]
cubes = np.linspace(
    1,21, 21)**3
#cubes = [n**3 for n in range(1,21)]
fig = go.Figure(
    data=[go.Bar( x=numbers,y=cubes)],
    layout=go.Layout(
        title = go.layout.Title(text='Numbers vs Cubes'),
        xaxis = go.layout.XAxis(title='Numbers'),
        yaxis = go.layout.YAxis(title='Cubes')
    )
)
# render the display to the browser (the default renderer)
fig.show()

'''
Numpy arange() return evenly spaced values within a given interval.
np.arange(3) produces this array: [0, 1, 2]
np.arange(3.0) produces this array: [ 0.,  1.,  2.]
np.arange(3,7)  produces this array: [3, 4, 5, 6]
np.arange(3,7,2)   produces this array: [3, 5]

arange() is similar to linspace(), but uses a step size
instead of the number of samples.

np.linspace(2.0, 3.0, num=5) produces
this 5 element array:[2.  , 2.25, 2.5 , 2.75, 3.  ])

https://numpy.org/doc/stable/index.html

'''