import pandas as pd
import plotly.graph_objects as go

df = pd.DataFrame(
    dict(
        names=['jim', 'tony', 'karen', 'leia', 'simmon'],
        final_exam_grade=[90,75,86,83,92],
        gpa=[97.5, 88.2, 76.6, 89.3, 82.8]
    )
)

fig = go.Figure(
    data=[
        go.Scatter( x=df.names,
                    y=df.final_exam_grade,
                    mode='markers',
                    #marker_color=df.final_exam_grade,
                    marker_color='red',
                    marker_size=15,
                    name='final_exam_grade'
        ),
        go.Scatter( x=df.names,
                    y=df.gpa,
                    mode='markers',
                    marker_color='green',
                    marker_size=15,
                    name='gpa'
        )
    ],
    layout=go.Layout(
        title = go.layout.Title(text='Grade Point Average vs Final Exam Grade'),
        xaxis = go.layout.XAxis(title='Students'),
        yaxis = go.layout.YAxis(title='Grades')
    )
)

# render the display to the browser (the default renderer)
fig.show()
'''
marker_color=df.final_exam_grade
The marker color changes with the grade score.
'''