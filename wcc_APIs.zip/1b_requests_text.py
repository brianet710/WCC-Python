# https://www.geeksforgeeks.org/response-text-python-requests/import requests
#
import requests
# Making a get request
response = requests.get('https://api.github.com')
print(type(response))
# prinitng request text
print(response) #status where 200 = success
print()
print(response.text) #print raw contents of the response object
