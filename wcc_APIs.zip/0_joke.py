'''
Two common computer-human interfaces are GUI and CLI.
A computer-computer interface is API. APIs commonly return
JSON data to the client computer making a request.

We can receive input from user, input from files and input
from the Internet (via an API).
A web API is a part of a website intended to be accessed from
programs running on other computers.

JSON data is the most common return data type.
Other possibilities include UTF-8 text, csv and more

We refer to web URL as an endpoint.
We 'consume' the data provided by the server to our request.
https://mannhowie.com/rest-api
'''

import json, requests
#https://official-joke-api.appspot.com/random_joke
#study the JSON data from above web address (URL). (raw data)

url = "https://official-joke-api.appspot.com/random_joke"
response = requests.get(url)
#consume the data. Save local copy in a variable
todays_joke = json.loads(response.text)
print(todays_joke) #print the imported json data
#print(type(todays_joke)) #confirm the json data is captured
# in this case .get has returned a dict
print()
print(todays_joke['setup'])
print(todays_joke['punchline'])
print("")
