# what is an API key? How to monetize an API?
# http://www.omdbapi.com/apikey.aspx?__EVENTTARGET=freeAcct
# Choose FREE
# https://www.omdbapi.com/
# note: case sensitive keys
import json, requests
url = "http://www.omdbapi.com/?t=titanic&apikey=324034ab"
#url = "http://www.omdbapi.com/?t=scream&apikey=324034ab"

response = requests.get(url)
#consume the data.
python_dictionary_values = json.loads(response.text)
#print(python_dictionary_values) #print the scream dictionary
print(python_dictionary_values['Genre'], end=' -- ')
print(python_dictionary_values['Rated'])
print(f"written by: {python_dictionary_values['Writer']}")
print("")
#url= "http://img.omdbapi.com/?apikey=324034ab&"
print(response.url)
#python_dictionary_values = json.loads(response.text)
'''
http://www.omdbapi.com/?t=jaws&apikey=324034ab
http:// is the web's hypertext transport protocol
www.omdbapi.com is this movie website's api endPoint
? indicates that what follows is an argument (think of the endpoint as a function we are calling)
t=jaws is a keyword argument. key=t value=jaws (we look to the api's documentation to find the meaning of t)
---www.omdbapi.com -  look for parameters--- Discover that t is movie title
& is and. We want to provide more keyword arguments.
apikey=youruniquekey   key-=apikey value=youruniquekey
'''
