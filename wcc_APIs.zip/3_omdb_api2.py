#OMDB pretty print
import requests
import pprint as pp
apiKey = '324034ab' #the api key lets the provider track usage
dataURL='http://www.omdbapi.com/?apiKey='+apiKey


movieTitle ='Fast & Furious'
params ={'s':movieTitle, 'type':'movie','y':'1954'}
#params ={'s':movieTitle, 'type':'movie'}
'''
series='Seinfeld'
params ={'s':series, 'type':'series'}
'''
response =requests.get(dataURL,params=params).json()
pp.pprint(response)
#print(response)
