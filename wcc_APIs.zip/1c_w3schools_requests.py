# an example of an API returning html code
import requests

#the required first parameter of the 'get' method is the 'url':
w3_webData = requests.get('https://w3schools.com/python/demopage.htm')

#The get() method returns a requests.Response object.

print(w3_webData.status_code)

#print the response text (the html source code in this case, NOT json):
print(w3_webData.text)
print()