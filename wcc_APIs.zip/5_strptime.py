#https://www.w3schools.com/python/python_datetime.asp
#strptime converts a string into a standardized time object
from datetime import datetime
datestring1="2020/3/15" #4 digit year hyphen separator
current_date = datetime.strptime(datestring1, '%Y/%m/%d')
print(current_date)

from datetime import datetime
datestring2="3-15-20" #4 digit year space separator
current_date = datetime.strptime(datestring2, '%m-%d-%y')
print(current_date)

from datetime import datetime
datestring3="5/17/22"   #2 digit year fwdslash separator
current_date = datetime.strptime(datestring3, '%m/%d/%y')
print(current_date)

#https://www.w3schools.com/python/python_datetime.asp
