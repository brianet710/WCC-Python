# https://www.geeksforgeeks.org/response-methods-python-requests/
# A look at the response object.
import requests
# Making a get request
response = requests.get('https://api.github.com/')
# print request object
print(response.url)
# print status code
print(response.status_code)
