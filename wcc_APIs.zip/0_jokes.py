'''
Note that this endpoint will return JSON data
which resembles a list of dicts. Confirm this yourself
by looking at the raw data returned from the endpoint.
Hence, we use a loop to consume it.
'''
# https://github.com/15Dkatz/official_joke_api
# The owner/provider of the API chooses the available endpoints
#White Castle, Dell computer, Mavis Tires

import json, requests
#Endpoint: https://official-joke-api.appspot.com/jokes/ten
#study the JSON data.

url = "https://official-joke-api.appspot.com/jokes/ten"
response = requests.get(url)
#print(response)
#https://www.geeksforgeeks.org/response-text-python-requests/

todays_joke = json.loads(response.text)
#print(todays_joke) #print the imported json data
#print(type(todays_joke)) #confirm we have a list of dicts
#loop through each element and find the joke in the data
for j in todays_joke:
    #print(j)
    print(j['setup'])
    print(j['punchline'])
    print('')
print("")
