'''
What is the output of the following line of code?

print(o0123)   #zero followed by the letter o

A. 291

B. 123

C. 83

D. 0123

'''
