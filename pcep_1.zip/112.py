'''
What is the output of the following snippet?

x = -1
y = 1
z = x
x = y
y = z
print(x, y)

A. -1 1
B. 1 - 1
C. 1 1
D. -1 1

'''
