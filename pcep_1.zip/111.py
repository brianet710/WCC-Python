'''
Following are the examples of Python Shortcut Operators (select all that apply:)

A. /=
B. *=
C. 0=
D. exp=
'''





