'''
Select the two true statements

A.
The print() function separates its outputted arguments with spaces.
B.
The print() function can use a sep (like separator) keyword argument.
C.
The sep argument's value cannot be an empty string.
D.
The sep argument's value has to be a single character.
'''
