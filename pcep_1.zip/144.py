'''
What will be the output when you run the following snippet?

my_tup = 'a', 'b', 'c', 'd'
print(my_tup[-1])

A.  -1

B.  d

C.  the code is erroneous

D.  ,

'''