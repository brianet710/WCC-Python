'''
What is the output of the following snippet?   

lst = ['a', 'b', 'c', 'd', 'e']
lst_2 = []
add = '0'

for number in lst:
    add += number
    lst_2.append(add)

print(lst_2[4])


A. ['0a', '0ab', '0abc', '0abcd', 0abcde']  

B. '0abcd'

C.  code is erroneous

D. 0abcde

'''


