'''
Create a for loop that counts from 10 to 1 and 
prints numbers divisible by 7 to the screen.

for i in range(10, 0, -1):
  #line of code   

A.  if i%7==0: print(i)

B.  if i // 7: print(i)

C.  print(i) if i%7==0

D. print(i) if i==7

'''

