'''
What is the result of running the following code line ?

print(4 ** 1 ** 4)

A. 16

B. 256

C. 4

D. 1

'''


