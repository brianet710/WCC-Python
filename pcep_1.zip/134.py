'''
What is the output of the following snippet?   

text = "PCEP Exam"
for letter in text:
    if letter == "P":
        break
    print(letter, end ="")

A.  C  

B.  P

C.  nothing is printed

D.  code is erroneous

'''


