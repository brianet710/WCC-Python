'''
What is the output of the following snippet?

list_1 = [3, 2, 1]
list_2 = []
for e in list_1:
    list_2.insert(1, e)

A.  [3, 1, 2]

B.  [3, 3, 3]

C.  [1, 2, 3]

D.  [3, 2, 1]
'''