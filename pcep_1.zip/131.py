'''
What is the result of running the following code snippet ?

nums =[1, 2, 3]
for i in range(len(nums)):
   nums.insert(i,i+2)
print(nums)   

A. [1, 2, 3, 4, 3, 2] 

B. [1, 2, 2, 3, 3, 4] 

C. [2, 3, 4] 

D. [2, 3, 4, 1, 2, 3] 

'''


