'''
What will the output be after running the following snippet?

print(9//3)

A. 3.0
B. 3
C. 9
D. 0
'''
)