'''
What code could you insert instead of the comment
to obtain the expeected result?
'''
#Expected Output:
#10
#11

#Code
dictionary = {}
my_list = ['10', '11', '12', '13']

for i in range(len(my_list)-2):
    dictionary[my_list[i]] = (my_list[i],)

for i in sorted(dictionary.keys()):
    item = dictionary[i]    
    #insert your code here