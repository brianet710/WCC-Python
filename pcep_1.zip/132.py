'''
What is the output of running the following code snippet ?
num3 = [num ** 3 for num in range(5)]
print(num3)
   

A. [0, 1, 8, 27, 64] 

B. [1, 2, 3, 4] 

C. [1**3, 2**3, 3**3, 4**3] 

D. Syntax Error

'''


