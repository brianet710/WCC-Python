'''
What is the expected output of the following snippet ?

num = input("Enter the number 2: ")
print(type(num))

A. type(2)

B. 2

C. <class 'str'>

D. <class 'int'>

E. <object string>

'''
