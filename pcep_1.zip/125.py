'''
What is the output of the following statements ?

var = 100
var -= 200 + 300
print(var)

A. -500
 
B. -400

C. 500

D. 600

'''
