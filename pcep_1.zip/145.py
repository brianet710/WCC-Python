'''
What will be the output after runnung the following code?

'''
tupl = ('Bush', 'Gardens') * 2
print(tupl)

tupl = tupl * 5
tupl.append(6)
print(tupl)

