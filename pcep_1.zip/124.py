'''
 What is the output of the following statement ?

greet = "Love is Respect"
print(greet[::])

A. "Love is Respect"

B. no output

C. Love is Respect

D. LoveisRespect

'''
