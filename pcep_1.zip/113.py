'''
Another version of Python is called

A. Jython
B. Javathon
C. Sharpton
D. Python 2020

'''