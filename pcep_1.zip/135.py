'''
What do you expect the following code to produce?   

name = []
while name:
    print('Good Boy')
else:
    print('Good Girl')    

A.  Good Boy

B.  Good Girl

C.  Good name=''

D. syntax error

'''


