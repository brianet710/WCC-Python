'''
What is the output of the following snippet?   

x = "3"
if x == 3:
   print("three")
elif x == '1':
    if int(x) > 3:
       print('two')
    elif int(x) < 3:
        print('one')
    else:
        print("two")
if int(x) == 3:
    print('five')
else:
    print("six")           


A. three  

B. five
 
C. six  

D. two

'''


