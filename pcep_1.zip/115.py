'''
What is the output of the following snippet?

1var = "3.9"
print("Python version: " + 1var)

A.
3.9
B.
Python version: 3.9
C.
Python version: 13.9
D.
invalid syntax
'''