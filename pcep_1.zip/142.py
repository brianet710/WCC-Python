'''
What is the output of the following snippet?   

'''
my_list = [0, 3, 12, 55, 2]
print(5 in my_list and 5 not in my_list)

'''
A.  True

B.  False

C.  5

D.  None

'''


