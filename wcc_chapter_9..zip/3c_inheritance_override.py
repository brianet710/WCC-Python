# Override a parent method
class Person:
    def __init__(self, n):
        self.name = n

    def print(self):          # print method for Person class
        print(f"{self.name}")

class Student(Person):
    def __init__(self, n, g):
        super().__init__(n)     # Call init of Person with the argument n.
        self.gpa = float(g)     # Set value of gpa to g.

    def print(self):            # print for Student class 'overrides' Print for Person.
        print(f"{self.name} {self.gpa}")

# Call the print method for Person.
# The Person version of Print outputs the name.
p = Person("Jade")
p.print()   # Persons method

# this calls the 'overriden' Print method for Student.
# The Student version of print outputs name and gpa.
s = Student("Kim", 3.53)
s.print()   # students method

print("")
