# super() allows us to build classes that extend the functionality
# of previously built classes. In this example we extend the
# functionailty of Person with a new class Student.
# All Student objects inherit all Person methods and attributes
# All Students ARE Persons. A Student IS-a Person

class Person:
    def __init__(self, n):
        self.name = n

    def getName(self):
        return self.name.upper()

class Student(Person):
    def __init__(self, n, g):       # Init function has two parameters, n and g.
        super().__init__(n)         # Call init of Person with the argument n.
        self.gpa = float(g)         # Set value of gpa to g.


p = Person("Jade")
print(p.getName())

s = Student("Kim", 3.53)
print(f"{s.name} {s.gpa}")
print(s.getName())  #getName is inherited from Person

print("")
#only Persons and Students can call the getName method
#nonStudent = getName('Fred')
'''
Inheritance is a concept in object-oriented programming
in which a class derives (or inherits) attributes and
methods (behaviors) from another class without needing
to implement them again.
https://realpython.com/python-super/
'''
'''
Make sure you understand what is required to instantiate
each of the classes in this example.
'''