'''
The Standard Library is included with Python.
The Python Standard Library includes a variety of modules.
To acces them we import them.
Math example: https://www.w3schools.com/python/module_math.asp
'''
#Run this example several times. Note the output.
from random import randint
from random import choice
#from Person import choice
#from random import choice

# Generate a random integer between 1 and 100 inclusive.
print( randint(1, 100) )

# Randomly select an element from a list or tuple.
names = ['scrabble', 'poker', 'monopoly', 'clue']

print(choice(names ))

#order matters when 2 modules are imported
#stand up sitdown