'''
 We assign private attributes by beginning their name
 with double underscore (beginning only). 
 Private attributes can only be accessed from methods of the class.
 '''
class Student:
    name = "Lokesh Singh" 
    __id = 1234    #__id is a private attribute
    
    # Method for Printing Private Attribute
    def Print_Id(self):
        print(f"The Id of student is : {self.__id}")
    
lokesh = Student()
print(f"The name of student is : {lokesh.name}") 

# Accessing private attribute using getter method
lokesh.Print_Id()
print(lokesh.name)
#print(lokesh.__id)    #private attributes 

# https://www.geeksforgeeks.org/private-attributes-in-a-python-class/
# good example to use to demonstrate find/replace: &quot;