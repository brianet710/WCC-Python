# We can import classes in the same way we import functions

#from modulename import Class1, Class2, Class3...
from Person import Person, Student, Address

# Create and print a Student.
s = Student("ali", 3.83, "33 Oak St.", "Downsville", "NY", "14437")
s.print()

print("")
