''' Class attributes and methods can be accessed by an object
 of that class using dot notation '''

class Person:  #instructions how to construct a Person
    """This class models a Person.""" #docstring

    """init method: this initializes a Person object."""
    def __init__(self, n, a):
        self.name = n
        self.age = a

person1 = Person("James", 23) # person1 is an instance of class Person
# Instance attributes can be read or modified using 'dot notation'.
# The syntax is: object.attributename
print(person1.name)
print(person1.age)

# Modifying instance attributes with the assignment operator.
person1.name = "Jim"
person1.age = 24

# Printing instance attributes.
print()
print(person1.name)
print(person1.age)

#print(person1)
