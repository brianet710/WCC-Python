# Defining methods to modify attributes

# Define a class student.
class Student:
    def __init__(self):
        self.name = "noname"        # default attribute values
        self.gpa = 0.0              # default attribute values

    def print(self):
        print(f"{self.name} {self.gpa:.2f}")

    # Set the value of the name attribute.
    def set_name(self, n):
        self.name = n

    # Set the value of the gpa attribute.
    def set_GPA(self, g):
        self.gpa = float(g) # convert into a floating point number before storing

# Instantiate and print an object of type Student.
s1 = Student()
s1.print()

# Modification by method of attributes.
# Print the updated object.
s1.set_name("Agatha")
s1.set_GPA(3)
s1.print()

#We can still modify the attributes directly via assignment
#s1.GPA = 41
#print(s1.GPA)
print("")
