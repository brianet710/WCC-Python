# Modifying attributes
class Student:
    def __init__(self):
        self.name = "noname"        # default attribute values
        self.gpa = 0.0              # default attribute values

    def print(self):
        print(f"{self.name} {self.gpa:.2f}")

# Instantiate and print an object of type Student.
s1 = Student()
s1.print()
print('')

# Direct modification of attributes.
# Print the updated object.
s1.name = "Agatha"
s1.gpa = 3.58
s1.print()
#print(type(s1))
print("")
