''' Inheritance is the capability of one class to derive or inherit
 the properties from another class. Advantages: reusability of code,
 resemblance to real world relationships between things.
 We say that Student IS-A Person. This is an inheritance relationship.
 A checking account IS-a bank account.
 A savings account IS-a bank account.
 A dog IS-a pet. So is a cat. So is a bird etc.

 What is inherited are a parent's class attributes and methods
'''
# Superclass or parent class.
class Person:
    def __init__(self):
        self.name = "noname"    # Set a default value for name.

# child class or derived class inherits from the superclass or parent 
class Student(Person):
    def __init__(self):
        super().__init__()      # Call the init function of Person, the Parent class.
        self.gpa = 0.00         # Set a default value for gpa.


# Print an instance of Student (two attributes, one of which is inherited).
stud1 = Student()
#print(stud1.name)
#print(stud1.gpa)
stud1.name="Art Garfunkel" # name is a Person attribute
stud1.gpa="4.00"           # gpa is a Student attribute

print(f"{stud1.name} {stud1.gpa}")
print("")

''' 
The takeaway from this example is that an object of a child class
has access to the attributes of that child class and its parent class
'''