# An object of class Student inherits from class Person
# An object of class Student IS A Person

# Composition: A Person HAS-A Address.
class Person:
    def __init__(self, name, street, city, state, zip):
        self.name = name
        self.address = Address(street, city, state, zip)    # Person contains an Address.
    def print(self):
        print(f"{self.name}\n{self.address.getAddressStr()}")

# Inheritance: Student IS-A Person.
class Student(Person):
    def __init__(self, name, gpa, street, city, state, zip):
        super().__init__(name, street, city, state, zip)    # Call init for Person.
        self.gpa = float(gpa)
    def print(self):
        print(f"{self.name} {self.gpa}\n{self.address.getAddressStr()}")

# Person instances contain an instance of type Address.
class Address:
    def __init__(self, street, city, state, zip):
        self.street = street
        self.city = city
        self.state = state
        self.zipcode = zip
    def getAddressStr(self):
        return f"{self.street}\n{self.city}, {self.state}, {self.zipcode}"

# Create and print a Student.
s = Student("Raymond Reddington", 2.95, "213-17 NORTHERN BLVD", "Bayside", "NY", "11361")
s.print()

print("")

# All Persons have Addresses
# All Students are Persons
# Therefore, all Students have Addresses
#All objects of the Address class have access to all Address methods
