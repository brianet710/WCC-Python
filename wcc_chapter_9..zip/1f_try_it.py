'''
Re-Open 1c_try_it.py

Add a method to the Student class.
The method name is print_my_info
The method should print the 3 Student attributes.

Call the method using dot notation.

Output Example:
ElonMusk 110549 99
'''