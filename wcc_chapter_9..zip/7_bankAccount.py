# A Bank Account class. Used by bank employee to create client accounts.
class BankAccount:
    def __init__(self, account_number, balance):
        self.__account_number = account_number  # Private attribute
        self.__balance = balance  # Private attribute

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Amount {amount} deposited successfully.")
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            print(f"Amount {amount} withdrawn successfully.")
        else:
            print("Insufficient balance or invalid withdrawal amount.")

    def get_balance(self):  # Getter method
        return self.__balance

Bruce_Lee_account = BankAccount("076545", 1000)
Bruce_Lee_account.deposit(500)
Bruce_Lee_account.withdraw(200)
print("Current balance: ", '$', Bruce_Lee_account.get_balance(),sep='') 
#print("Current balance: ",'$', Bruce_Lee_account.get_balance()) 

'''
When we provide multiple comma-separated arguments to print
the default output is to separate each with a space.
'''
#print(5,6,7,8,9)
#print(5,6,7,8,9,sep='')