'''This is a module of Classes
 Store related classes in one module for import.
 Optimally, non-related classes should each be in their own modules'''
class Person:
    def __init__(self, name, street, city, state, zip):
        self.name = name
        self.address = Address(street, city, state, zip)
    def print(self):
        print(f"{self.name}\n{self.address.getAddressStr()}")

class Student(Person):
    def __init__(self, name, gpa, street, city, state, zip):
        super().__init__(name, street, city, state, zip)
        self.gpa = float(gpa)
    def print(self):
        print(f"{self.name} {self.gpa}\n{self.address.getAddressStr()}")

class Address:
    def __init__(self, street, city, state, zip):
        self.street = street
        self.city = city
        self.state = state
        self.zipcode = zip
    def getAddressStr(self):
        return f"{self.street}\n{self.city}, {self.state}, {self.zipcode}"





# function to demo the significance of order of imports
# demo with standard_library.py
def choice(a_list):
    return(sorted(a_list))
# by itself, this py file produces no output
# this module needs to be imported. see example 5-class-import
