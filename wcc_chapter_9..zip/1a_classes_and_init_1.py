''' A class is a blueprint for creating objects.
An object is simply a collection of attributes and
methods(functions) that act on that data.
'''

#Create a class Person which is used to create Person objects.
class Person:
    """This class models a Person."""
    """init method: this initializes a Person object."""
    # A function that is part of a class is called a 'method'.
    # The __init__ method runs whenever we create a new instance
    # of the class Person.
    def __init__(self, n, a):
        self.name = n   # name is our first attribute
        self.age = a    # age is our second attribute

'''In Python, we don't exactly "call" a class in the same way
 we call a function. Instead, we instantiate a class to create
an object '''
p1 = Person("Jim", 23)   # instantiation=create an instance
p2 = Person("Sue", 22)   # p1 and p2 are instances of class Person
print("None of the above statements produce output")

'''
what happenned in the init process:
p1, "Jim", 23  -> self, n, a
p2, "Sue", 22  -> self, n, a

'''
