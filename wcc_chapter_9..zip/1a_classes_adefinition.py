'''
A definition:
A class is a user-defined blueprint or prototype from which objects
are created.
Classes provide a means of bundling data (attributes) and
functionality (methods) together.
Creating a new class creates a new type of object, allowing
new instances of that type to be made (instantiated).

Object Oriented programming (OOP) is an approach to programming
which models its data structures after real-world objects:

Take a car as an example:
A car has attributes:
length, width, weight, number of doors, engine type, owner, etc.
A car has functionality:
It starts. It accelerates. It brakes. It turns. It honks, etc.

Any car, my car for example, is one instance of the class car.
An instance is a single occurrence of something.
'''
