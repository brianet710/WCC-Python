#Overriding methods & calling overridden parent methods
class Animal:
    def speak(self):
        print("Generic animal sound")

class Dog(Animal):
    def speak(self):
        print("Woof!")

class Cat(Animal):
    def speak(self):
        super().speak()  # Call the parent's speak method
        print("Meow!")

# Create instances of the classes
animal = Animal()
dog = Dog()
cat = Cat()

# Call the speak method on each instance
animal.speak()
dog.speak()
cat.speak()


