''' 
Create a class named Student.
The Student class has 3 attributes:
name
id
gpa

Instantiate a Student object with this info:
ElonMusk
110549
99
'''
#Save this file. You will use it again.