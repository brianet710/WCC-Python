# __init__    2 prefix and 2 suffix underscores
# known as a magic method or a dunder method.
# Equiv to a constructor function in other languages
#__init__ gets called when we instantiate an object

class Student:
    # init function with optional parameters.
    def __init__(self, n="noname", g=0.00):
        self.name = n
        self.gpa = float(g)

    # Print student information.
    def print(self):
        print(f"{self.name} {self.gpa:.2f}")

# Call init (instantiate a Student) with no arguments.
s1 = Student()
s1.print()

# Call init with one positional argument (goes to the first parameter).
s2 = Student("James")
s2.print()

# Call init with one keyword argument.
s3 = Student(g=3.23)
s3.print()

# Call init with two arguments.
s4 = Student("John", 2.52)
s4.print()

print("")
