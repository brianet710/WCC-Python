class Person:
    """This class models a Person."""

# To instantiate a person we need to provide a name & age
    def __init__(self, n, a):
        self.name = n   #instance attribute
        self.age = a    #instance attribute

    """greeting method: A Person object can print a custom greeting."""
    # This is an instance method of the Person class.
    def greeting(self, msg):
        print(f"{self.name} says {msg}")

# Multiple instances can be created of the Person class,
# each of which have their own memory space.
p1 = Person("Jim", 23)
p2 = Person("Jane", 34)
print(f"{p1.name} is {p1.age}")
print(f"{p2.name} is {p2.age}\n")

# Each instance has its own attributes which can be read and/or modified.
p1.age = 24
p2.age = 35
print(f"{p1.name} is {p1.age}")
print(f"{p2.name} is {p2.age}\n")

# Calling methods for each instance.
p1.greeting("Hi!")
p2.greeting("Bye!")

print("")
# We can think of the class as the instructions to build an object
# We can make (instantiate) as many objects of the class as we want
