''' Composition
We say that a Person 'HAS-A' Address. This is a composition relationship.
Person class includes an attribute which is an instance of the Address class.
 An object contains an object of another class.
 A car has headlights. A person has a bank account.
'''
class Person:

    #"Donovan", "21416 41st Ave", "Bayside", "NY", "11361"---
    def __init__(self, name, street, city, state, zip):
        self.name = name
        self.address = Address(street, city, state, zip) # Composition

    # Print method uses the getAddressStr method from Address to print a complete Person object.
    def print(self):
        print(f"{self.name}\n{self.address.getAddressStr()}")

# Address is a class which can be used inside other classes.
class Address:
    def __init__(self, street, city, state, zip):
        self.street = street
        self.city = city
        self.state = state
        self.zipcode = zip

    # This method returns all address data as a string.
    def getAddressStr(self):
        return f"{self.street}\n{self.city}, {self.state}, {self.zipcode}"

    # Print all address data.
    def print(self):
        print(f"{self.street}\n{self.city}, {self.state}, {self.zipcode}")


# Create and print an address.
a = Address("185-04 Horace Harding Expy", "Flushing", "NY", "11365")
a.print()
print("")

# Create and print a Person (including the Person's address).
p = Person("Donovan", "21416 41st Ave", "Bayside", "NY", "11361")
p.print()

print(p.address.city)
print(p.address.state)

# Is Person a subclass of Address?  NO
# Is Address a subclass of Person?  NO
# Review line 12. This establishes the composition relationship.

#print(type(p.address))
#print(type(p.name))

'''
The data type of the name attribute of Person is string.
The data type of the address attribute of Person is an Address object.
'''