# Methods are functions of a specific class
class Person:
    """This class models a Person."""

    """init method: this initializes a Person object."""
    def __init__(self, n, a):
        self.name = n
        self.age = a

    """greeting method: A Person object can print a custom greeting."""
    # This is an instance method of the Person class.
    # Notice how we access the attribute name.
    def greeting(self, s):
        print(f"{self.name} says {s}")

person1 = Person("Jim", 23)  #p1 and p2 are objects modelled on the Person class
person2 = Person("Jane", 36) #They inherit the attributes and methods of Person

# Instance methods are calling using 'dot notation'
# The format is: object.methodname(parameters)
person1.greeting("Hi!")
person2.greeting()

print("")
