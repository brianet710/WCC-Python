'''
Class attributes are common to all instances of a class
 https://www.pythontutorial.net/python-oop/python-class-attributes/
 A class attribute is declared inside the class but outside
the init method. The value of a class attribute is the same
for all instances of that class.
'''
class Circle:
    PI = 3.141592 # PI is a class, not instance, attribute
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return self.PI * self.radius**2

circle_05 = Circle(5) #create a circle object

print("The area of the circle is", circle_05.area())

print("The value of PI is",circle_05.PI)

# Area of a circle = PI * Radius Squared
