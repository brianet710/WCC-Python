'''A=4πr*r     Area of a sphere = 4 pie r squared
A sphere with a radius of 5 has an area of 314.1592 
A = (4)(3.14)(5*5)
'''
PI= 3.141592
def sphereArea(radius):
    PI= 3.141592
    area= 4*PI*radius**2
    return area

print(sphereArea(7))
print(sphereArea(50))


print("")
