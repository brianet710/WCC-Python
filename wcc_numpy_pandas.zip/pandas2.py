'''
A pandas dataset, a car dealership
'''

import pandas

mydataset = {
  'cars': ["BMW", "Volvo", "Ford"],
  'forSale': [13, 7, 12]
}

myvar = pandas.DataFrame(mydataset)

print(myvar)
print(type(myvar))
print(mydataset)
#print(mydataset['cars'])

# We put our data into Pandas in order to gain access to pandas operations.