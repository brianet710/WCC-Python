import numpy as np
# 0-D array
arr0 = np.array(42)
print(arr0)
print()

# 1-D array 
arr1 = np.array([1, 2, 3, 4, 5])
print(arr1)
print()

# 2-D array
import numpy as np
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
print(arr2)
print()


#vanilla python: a list of lists
x = [[1,2,3], [7,8,9]]
print(x)