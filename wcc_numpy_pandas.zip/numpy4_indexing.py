import numpy as np


#indexing works the same way as python lists
arr = np.array([1, 2, 3, 4])

print(arr[2] + arr[3])

#slicing works the same way as python lists
arr = np.array([1, 2, 3, 4, 5, 6, 7])

print(arr[1:5])