'''
pandas dataframes
Pandas is a Python library used for working with data sets.
It has methodss for analyzing, cleaning, and manipulating data.
'''


import pandas as pd

df = pd.read_csv('data.csv')
print()

print(df.to_string()) 
print()

#print(pd.__version__) #what version of pandas is installed on the client system