'''
A Pandas Series is like a column in a table.
It is a one-dimensional array containing any data type.
'''
import pandas as pd
import pandas as pd

rolls_of_die = [1, 7, 2, 6, 7]

myvar = pd.Series(rolls_of_die)

print(myvar)
#create labels for a series
a = [1, 7, 2]

myvar = pd.Series(a, index = ["x", "y", "z"])

print(myvar)