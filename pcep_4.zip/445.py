'''
Which of the following statements correctly creates
a tuple (select all that apply):
'''
A. tup1 = (5, 3)
B. tup2 = tuple((5,3,))
C. tup3 = tup((5,3,))
D. tup4 = 'X', 'Y', 'Z'

#Notes
myTup = tuple((7,)) #legal
#myTup = tuple((7))  #illegal

#Line 7: There is no tup() method