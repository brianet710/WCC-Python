# What is the  output?
dct = {'one': 'one', 'two': 'two', 'three': 'three'}
v =dct['three']

for k in range(len(dct)):
    v = dct[v]

print(v)

'''
A. one
B. two
C. three
D. four

'''

#Note the loop runs 3 times and does the same assignment each time.
# The value of v remains unchanged in the code.
