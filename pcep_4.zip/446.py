# What is the output?

list1 = [3, 2, 1]
list2 = []
for e in list1:
    list2.insert(1, e) #(where to insert it, value to insert)
print(list2)    

'''
A. [3, 1, 2]
B. [3, 2, 1]
C. [1, 2, 3]
D. [3, 3, 3]
'''