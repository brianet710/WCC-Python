# What is the output?

if not(True):
    print("Hello, Students!")
else:
    print("Python Rocks!")    

'''
A. Hello, Students!

B. Python Rocks!

C. 
Hello Students!
Python Rocks!

D. Syntax Error

'''    