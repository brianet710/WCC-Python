'''
What do you call a tool that lets you launch your code step by step
and inspect it at each moment of execution?

A. A console
B. A text editor
C. A debugger
D. An IDLE window
'''