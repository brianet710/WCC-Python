'''
Which ONE of the statements below will print
"""Jython"""

'''
print("""Jython""")
print('"""Jython"""')
print(3*"Jython3*")
print("""Jython""")

'''
'''