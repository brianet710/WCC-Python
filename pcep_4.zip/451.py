# What is the output?

def my_func(n):
    print(n, end= ' ')
    n += 1
    print(n, end=' ')

var = 1
my_func(var)
print(var)    

'''
A. 1 2 1
B. 1 2 2
C. 1
D. 1 1 1

'''

''' Note: Changes to a local var inside a function do not
affect that global vars value. ''' 