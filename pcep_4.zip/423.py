# The \t character is treated by the print statement as

'''
A. It stops its execution
B. It duplicated the letter following the backslash
C. It is a string literal" \t will be sent to the console
D. It outputs a horizontal tab
'''