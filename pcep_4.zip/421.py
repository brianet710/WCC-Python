# What is the output?

x = 0.5 / 1 + 5 // 5 + 2**4
print(x)

'''
A. 17.5
B. 17
C. 8.5
D. 8
'''



#pedmas: parenthesis, exponents, division, multiplication, subtraction, addition
