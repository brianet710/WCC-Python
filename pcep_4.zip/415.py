# What is a computer source code?

'''
A. Another name for a command documentation file
B. Machine code stored in a computer's RAM
C. A program written in a high-level programming language
D. A copyright information snippet

'''