'''
Choose the correct statements about the break statement
in a for loop. Choose all that apply.'''

'''
A. Break will terminate the entire loop.

B. Break statement alters the flow of the loop.

C. Break statement in an inner loop will terminate
 both the inner and outer loops.
 
D. Break will terminate the current iteration but 
will resume with the next iteration. 


'''