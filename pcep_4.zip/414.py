'''
 Select the ONE correct statement:

A. subtraction precedes multiplication

B. multiplication precedes addition

C. Floor division precedes ceiling division 

D. Exponentiation uses left-side binding
'''

import math
x = 5.6
y = 5.4
print(math.ceil(x))
print(math.ceil(y))
# ceil() returns smalles integer not less than x.

print(math.floor(x))
print(math.floor(y))
#Returns: 
# floor() returns largest integer not greater than x.

#floor division and integer division (//) are similar.
print()
print(7 // 2)
print(-7 // 2)
'''If both floor division and ceiling division are in the same expression 
without any parentheses, the evaluation happens from left to right. '''

#Exponentiation usues right-side binding
print()
print( 3 ** 2 ** 3 )
print((3 ** 2) ** 3)

