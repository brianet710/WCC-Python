#How many hashes (#) will be printed?

for i in range(9):
    print("#")
else:
    print('#')

'''
A. 8
B. 9
C. 10
D. 11
'''        
