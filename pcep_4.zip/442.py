# What is the output?

text1 = (1, 2, 3)
text2 = ('hammer', 'level', 'screwdriver')
print(text1 + text2)
'''
A.  (1, 2, 3), ('hammer', 'level', 'screwdriver')
B.  ('hammer', 'level', 'screwdriver', 1, 2, 3)
C. (1, 2, 3) + ('hammer', 'level', 'screwdriver')
D. (1, 2, 3, 'hammer', 'level', 'screwdriver')

'''
#Note the differnece when we provide 2 arguments to print below:
# print(text1, text2)
