'''
Python's direct competitors with comparable properties and predispositions are:
(select 2)

A. Perl
B  Ruby
C. C++
D. Windows OS

'''
# A & B are scripting languages. C++ is compiled.
