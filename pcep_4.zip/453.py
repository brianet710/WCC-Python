'''
A way of function argument parsing in which the order
of the arguments determines the initial parameter
values is referred to as:

A. keyword
B. sequential
C. positional
D. refernetial


'''