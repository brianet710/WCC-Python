# A function definition:

'''
A. must be placed before the first invocation.
B. may be placed anywhere after the first invocation.
C. must be at the top of our script.
D. must be placed at the end of our script.

'''

