# What is the output?
def fun(x):
    x += 1.5
    return x

x = 1.5
x = fun(x + 1)
print(x)

'''
A. The code is erroneous.
B. 1.5
C. 3.0
D. 4.0
'''