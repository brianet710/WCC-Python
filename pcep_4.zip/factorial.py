# The factorial of a number, n  is n multiplied by n -1 until we get to zero.
# Factorial of 3 = 3 * 2 * 1. Factorial of 4 = 4 * 3 * 2 * 1
def factorial(n):
    if n == 1:
        return 1
    else:
        return n * factorial(n -1)
    
print(factorial(3))

# https://www.youtube.com/watch?v=DUC1qg7ZaRg
