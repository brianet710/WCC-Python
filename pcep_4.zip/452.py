# What is the output?

x = 33
def trans_me():
    global x
    x += 33
    print(33 + x, end='')

trans_me()
print(x)

'''
A. 9966
B. 9966
C. 9933
D. 6633
'''

#Note: The func prints 99 (33 + 66).
# The global var x is set to 66.