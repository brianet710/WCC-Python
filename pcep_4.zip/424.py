'''
The value of three point fourteen times ten raised 
to the power of 6 should written as:
Choose TWO
'''

#A. print(3.14E6.0)
#B. print(3E14.6)
#C. print(3.14E6)
#D  print(3.14e6)


#The decimal place will move right 6 places