# What is the output?

for i in range(3):
    print(i, end =" ")

print(i+1)    

'''
A. 1 2 3
B. 0 1 2 3
C. 0 1 2
D. 0123

'''