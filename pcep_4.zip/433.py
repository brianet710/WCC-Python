#How many pluses (+) will be sent to the console?

x = 1
while x < 20:
    print('+')
    x = x << 1

'''
A. five
B. ten
C. two
D. zero
'''    

'''
How x changes:
000001
000010
000100
001000
010000
100000  #32 while x<20 returns False 

'''