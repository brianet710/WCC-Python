# What is the output?

my_list = []
for i in range(5, 0, -1):
    my_list.append(i+1)
print(my_list)    

'''
A. [5, 4, 3, 2, 1]
B. [0, -1, -2, -3, -4]
C. [6, 5, 4, 3, 2]
D. [0, 1, 2, 3, 4]
E. [6, 5, 4, 3, 2, 1]
'''

'''
#descending range behavior
for i in range(2,0,-1):
    print (i)
'''

