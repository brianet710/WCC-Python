# What is the output?
def snip():
    print(r + 1, end = '')

r = 20
snip()
print(r)
'''
A. 2120
B. 21 20
C. 2121
D. 2020
'''    