'''
Select the TWO true statements about Python syntax:

A. Only one instruction in a line.

B. Any number of instructions in a line.

C. Comments only at the top of the source file.

D. A single line and multi=line comments allowed

'''

# https://peps.python.org/pep-0008/#other-recommendations
# Search -> compound statements
