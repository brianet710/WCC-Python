#What is the output?

str = "Get Ready!"
str = str[-6:len(str)]

print(str)

'''
A. Get R
B. str is a keyword. Illegal statement
C. Ready!
D. Get Ready!

'''

# What char is at index -6.
# What is the length of the string?