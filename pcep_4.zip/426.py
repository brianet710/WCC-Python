# What will be the output if the user enters 44?

v1 = int(input())
print(len(v1))

'''
A. lenv1
B. 2
C. 1
D. Type Error: object of type 'int' has no len()

'''