# What is the output?

d = {'one': -1, 'two': 1}
d['one'] = 1

print(d)

'''
A. {'one': 0}
B. {'one': -1, 'two': 1}
C. {'one': -1, 'two': -1}
D. {'one': 1, 'two': 1}
'''

# This is a simple modification of a dictionary value using assignment