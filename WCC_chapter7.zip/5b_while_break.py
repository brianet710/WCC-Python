# Breaking a while loop
# initialize a variable 
n = 0

# while loop: repeat as long as the condition is true
while n <= 10:
    n += 1              # increment n by 1
    print(n, end=" ")   # print n
    if n == 5:          # when n is 5
        break       # terminate the loop early
print("")
print("This statement executes when the loop terminates...")
