#Try to anticipate the output
#Loop 1
n = 5   
while n > 0:
    n = n - 1   #n-=1
    if n == 2:
        break #skip the else clause
    print(n)
else:
    print("Loop is finished")
print("")

#Loop 2 
n = 5
while n >= 0:
    n = n - 1
    if n == 2:
        continue
    print(n)
else:          # we enter here when the while loop ends
    print("Loop is finished")
