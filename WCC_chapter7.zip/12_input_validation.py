#Validating user input
while True:
    age = input('Enter your age: ')
    if age.isdigit():
      print(age)
      break
    else:
      print("\nLet's Try again")
      continue
'''
https://www.w3schools.com/python/python_ref_string.asp
'''