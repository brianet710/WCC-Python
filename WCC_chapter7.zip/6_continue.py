# continue brings us immediately back to the loop statement
# Print all the odd numbers
n = 0
while n <= 21:
    n += 1              # increment n by 1
    if n%2!=0:          # if n is odd do not print the mumber
        continue      # skip the current iteration and restart the loop
    print(n, end=" ")
print("")

''' In this program, the continue statement allows for line 8
to be skipped when a number is odd '''