''' The input() function allows us to get user input.
Syntax: input(prompt) 
where prompt is a string or a variable reference to a string.
The prompt guides the user to provide appropriate input. '''
# request input from the console and store into a variable
user_nbr = input("Enter a number: ")
print(user_nbr)

user_word = input("Enter a word: ")
print(user_word)

# using a variable to the prompt message
prompt = "Enter your full name: "
name = input(prompt)
print('Welcome '+ name)
