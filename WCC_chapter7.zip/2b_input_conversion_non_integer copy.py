print("")

print("Enter two numbers to sum: ")

# request a value from the console
a = input("number 1: ")
# convert the input data from a string to a floating point number
a = float(a)

# request and convert into one step
b = float(input("number 2: "))

print(f"The sum of {a} and {b} is {a+b}.")

print("")
