# infinite loop, counting the wrong way
n = 1

while n <= 21:
    n -= 1  # n keeps reducing so condition is always true (infinite loop)
    print("redrum " , end=" ")
print("")
