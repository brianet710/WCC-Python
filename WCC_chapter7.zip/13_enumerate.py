''' enumerate()is a built-in function used for
    assigning an index to each item of an iterable
    object. This saves the need of initializing and
    incrementing a counter variable in a for loop'''

# months of the year
months = ["Jan","Feb","Mar","April","May","June"]

for i, m in enumerate (months):
		print(i,m)    
print("")
# Enumerate's start parameter. Default is 0

for index,name in enumerate(months, start =1):
    print(index,name)
