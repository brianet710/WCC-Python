#input data is string data
print("")

print("Enter two numbers to sum: ")

# request a value from the console
a = input("number 1: ")
# convert the input data from a string to an integer
a = int(a)

# request and convert in one step
b = int(input("number 2: "))

print(f"The sum of {a} and {b} is {a+b}.") #addition not concatenation

#Using f-string to format large numbers
#print(f"{a+b:,}") #format numbers with comma separator. e.g. 123,456,789 

print("")
#print(type(a))
#print(type(b))
