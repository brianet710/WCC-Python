'''
The while loop is used to execute a block of statements
repeatedly until a given condition is satisfied.
The while loop requires the variable used in the looping
expression to be 'ready'.
'''
# initialize a variable to 1
n = 1
# while loop: repeat as long as the condition is true
while n <= 10:
    print(n, end=" ")
    n += 1     # n=n+1
print('')

print(n) #what is n after the loop ends?
