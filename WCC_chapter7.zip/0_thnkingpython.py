''' Think Python
How to Think Like a Computer Scientist
Allen Downey
https://greenteapress.com/wp/think-python-3rd-edition/'''
''' What is a program?
A program is a sequence of instructions that specifies how to perform
a computation. The computation might be something mathematical,
such as solving a system of equations or finding the roots of a
polynomial, but it can also be a symbolic computation, such as
searching and replacing text in a document or something graphical,
like processing an image or playing a video.
A few basic instructions appear in just
about every language:
Input: Get data from the keyboard, a file, the network
Output: Display data on the screen, save it in a file, send it
over the network, etc.
Math: Perform basic mathematical operations like addition and
multiplication.
Conditional execution: Check for certain conditions and run the
appropriate code.
'''
'''
The single most important skill for a computer scientist is
problem solving. Problem solving means the ability to formulate
problems, think creatively about solutions, and express a
solution clearly and accurately. As it turns out, the process of
learning to program is an excellent opportunity to practice
problem-solving skills.
'''
'''
“Everybody should learn to program a computer, because it
teaches you how to think.” -Steve Jobs
'''
