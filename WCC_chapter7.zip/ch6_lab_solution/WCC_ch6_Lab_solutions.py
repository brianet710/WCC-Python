
print("Question #1 ")
players = { 'Adam Vinatieri': 49,
           'Trevor Lawrence': 21, 
           'Kyle Pitts': 22 }

youngest =100
for player,age in players.items():
    if age < youngest:
        youngest = age
        name = player

print(name,youngest)

#print(f"The youngest player is {(min(players, key=players.get))}. He is {(min(players.values()))} years old.")

print("")
print("Question #3")

superheros = {
    'batman': {
        'name': 'batman',
        'superpowers': ['intelligence', 'technology', 'science']},
    'superman': {
        'name': 'superman',
        'superpowers': ['flight', 'strength', 'vision']}}
 
print(superheros['batman']['name'] + ':', superheros['batman']['superpowers'])
print(superheros['superman']['name'] + ':', superheros['superman']['superpowers'])

print(" ")
print("Question #4")

John = { 'name': 'John',
        'grades': [90,84,64]}

Sarah = {'name': 'Sarah',
         'grades': [73,80,63]}

Lara = {'name': 'Lara',
         'grades': [95,72,83]}

students = [John, Sarah, Lara]


for s in students: 
    passing = []
    for grade in s['grades']:
        if grade >= 65:
             passing.append(grade)
             
    avg_passing_grade = sum(passing) / len(passing)
    
    print(f"{s['name']}", end=" ")
    print(" ".join(str(grade) for grade in passing), end=" ")
    print(f"- Avg = {avg_passing_grade:.2f}")
  

numbers = [1, 2, 3, 4]

# Convert numbers to strings and join them with commas
result = ", ".join(map(str, numbers))

print(result)
print(type(result))
# https://www.google.com/search?client=firefox-b-1-d&q=python+join+map+str
