#Revisiting Chapter3 example 8

# initialize a list with multiple 3s
nums = [1,3,5,8,2,3,5,4,3,3,3,9,3]
print(nums)
print("")

# remove an element from the list (removes the first element only)
nums.remove(3)
print(nums)
print("")

# remove all instances of the specified value from a list
while 3 in nums:
    nums.remove(3)
print(nums)
