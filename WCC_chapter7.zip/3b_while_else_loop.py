# while else

n = 1
# while loop: repeat as long as the expression is True
while n <= 10:
    print(n, end=" ")
    n += 1
else:
 print("\nDone counting.")    # code to run when loop completes (condition is false)

print("")
