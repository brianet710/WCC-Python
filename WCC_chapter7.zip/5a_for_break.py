'''break causes the loop to end.
Program flow continues at the first
statement outside the current loop. '''

# for loop with early termination using the break command
for n in range(1, 20):
    print(n, end=" ")
    if n == 5:
        break

print("\nThis statement executes when the loop has ended")
