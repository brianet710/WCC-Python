'''
The join() method takes all items in an iterable and joins them into
one string. A string must be specified as the separator.
'''
#convert list data into a string
toDoList = ["walk the dog", "wash the car", "mow the lawn "]
toDo_string = " & ".join(toDoList)

print(toDo_string)
print()

#convert dict data into a string
myDict = {"name": "Brian", "school": "WCC", "dept": "CIS"}
mySeparator = "---"

stringData = mySeparator.join(myDict.keys())
print(stringData)
stringData = mySeparator.join(myDict.values())
print(stringData)
