'''
Imagine you have an international user base.
You want to collect the name of each user's city
and temperature. We'll start with a single user.

Prompt the user for their city and temperature.
Save this information in variables. 

Output Example->
Today's temperature in Oslo is 33 degrees.

'''