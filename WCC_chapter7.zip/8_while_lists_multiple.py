# initialize two lists
days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
appointments = []

# while lists are better then for loops for modifying a list during iteration
# Note that the condition is true until all days are removed (making it false)
while days:
    day = days.pop()
    appointments.append(day.lower())

# for loops are better for accessing individual elements in lists
for a in appointments:
    print(a)

print("")
