# For loop vs While loop

colors = ['black', 'white', 'gray', 'red', 'green', 'blue']
for color in colors:
   print(color, end= " ")

print()
# while loop to print list items
colors = ['black', 'white', 'gray', 'red', 'green', 'blue']
i = 0
while i != len(colors):
  print(colors[i], end =" ")
  i = i + 1
