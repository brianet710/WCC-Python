#input data is string data
print("")
print("Enter two numbers to sum: ")

# request a value from the console
a = input("number 1: ")

# request a second value from the console
b = input("number 2: ")

print(f"The sum of {a} and {b} is {a+b}.")

'''

When used with strings, + is the concatenation operator.
We must convert strings to numbers in order to perform addition.
'''
#print(type(a))
#print(type(b))