'''
infinite loop (a loop that never ends)
hit Ctrl-C to stop the execution of the loop
if this does not work, "kill" the Python process
which is consuming the CPU cycles
using Task Manager (Windows) or Top (OSX)
https://medium.com/macoclock/top-a-powerful-command-for-your-macos-terminal-d284fe3a16b
'''
n = 1
while n <= 10:    
    print(n, end = " ")
    #n +=1  
print("")
