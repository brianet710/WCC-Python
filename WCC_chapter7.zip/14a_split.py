# split() produces a list from a string

print('~~~ Welcome to the Grade Averager ~~~')
input_string = input("Enter the grades separated by a space: ")
#convert input string into a list
#The split() method takes string input and produces a list
my_list  = input_string.split(' ')
#print(my_list)

#convert list elements into integers
int_list=[int(n) for n in my_list]
#print(int_list)
# Compute the grade average
print('The grade average is: ', end='')
print(sum(int_list) / len(int_list))
