print("")
longPrompt = 'Westchester Community College\n'
longPrompt += 'Student Survey\n'
longPrompt += 'On a scale from 1 to 5\n'
longPrompt += "How did you enjoy the class? "

response = input(longPrompt)
#save participant response to a file
print("Thanks for your feedback!")

'''
x = x + y is the same operation as x += y
The plus-equals operator += provides a convenient way
to add a value to an existing variable and assign the
new value back to that same variable.
In the case where the variable and the value are strings,
this operator performs string concatenation instead of addition.

The autoincrement opertion:
x += 1 is the same operation as x = x+1

The autodecrement operation:
x -= 1 is the same operation as x = x-1
'''
