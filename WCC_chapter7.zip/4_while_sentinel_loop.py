'''A sentinel value is a value that is used to
   terminate a loop whenever a user enters it'''
print("")
# initialize a variable to an empty string
n = ""
# repeat asking for input unil the user types 'quit'
while n != "quit":
    n = input("Enter a number or 'quit' to stop repeating: ")

print("")


