# A data entry program. Registering visitors.
# Populate a dictionary with user input
people = {}

# while loop requests values until user enters 'quit'
while True:
    name = input("Enter full name or 'quit' to stop: ")
    if name.lower() == 'quit':     #ignore sentinel case
        break;
    age = input("Enter an ID: ")
    people[name] = age    # add this dict item

# print each key and value of the dictionary
for k in people.keys():
    print(f"{k} {people[k]}")

print("")
print(people)

'''
A while(True) loop must contain a break statement
in order to avoid an infinite loop
'''