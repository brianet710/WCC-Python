'''
What is the output?

numbers = [177, 7, 2, 1]
print(len(numbers), numbers[-1], numbers[1])



A.  177 1 7
B.  4 1 7
C.  177 2 1
D.  4 7 7


'''