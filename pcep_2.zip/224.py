'''
What is the output if the user enters two
lines containing 11 and 7 respectively?
'''
x = int(input())
y = int(input())
      
x = x % y
x = x % y
y = y % x
print(y)

'''
A. 1 
B. 4
C. 4
D. 3


'''