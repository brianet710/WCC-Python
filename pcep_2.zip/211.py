'''
If a code compiler finds an error



A. It terminates and issues an error message
B. It skips the line of code with the error.TabError
C. It enters debugger mode.
D.  It switches to the pre-processor stage.
'''