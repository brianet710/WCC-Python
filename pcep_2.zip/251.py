'''
What is the output?

def message():
    alt = 10
    print("Hello Susan!", end = ' ')

print(alt)    

A.  Hello Susan! 10
B.  NameError exception will be thrown
C.  10
D.  Hello Susan!

'''


