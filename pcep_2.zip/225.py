'''
The ** operator



A. performs exponentiation
B. performs floating-point multiplication
C. performs left-binded multiplication
D.  exists only in Python 2.7 and higher


'''