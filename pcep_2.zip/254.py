'''
If a list is passed to a function as an argument
then, deleting any of its elements inside the function
'''


'''
A.  Will affect the list
B.  Will cause a runtime error
C.  Will not affect the list
D.  is illegal

'''
