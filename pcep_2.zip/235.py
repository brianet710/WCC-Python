'''
What is the output?
'''
i = 0
while i <1:
    print("Play", end = ", ")
    i += 1
else:
    print("Again")
'''
A. Play 

B. Play, Again

C. Play Again

D.  "Play", Again


'''