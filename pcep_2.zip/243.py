'''
What is the output?

list1 = ["blue", "green", "red"]
list2 = list1
list3 = list2
del list1[0]
del list2[0]
print(list3)

A.  ['blue']
B.  [red]
C.  red
D.  ['red']
E.  ["blue", "green", "red"]

'''