'''
The // operator
'''

      
'''
A. does not exist
B. performs regular division
C. performs integer division
D.  performs modulo division
'''