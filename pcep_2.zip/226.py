'''
What sill be the output?

b1 = 0b111
b2 = b1 << 3


A. 0b000111
B. 0b011111
C. 0b011110
D.  0b111000


'''
#https://www.w3schools.com/python/trypython.asp?filename=demo_oper_left_shift