'''
The most important difference between integer and floating-point 
numbers lies in the fact that:



A. They cannot be used simultaneously
B. They are stored differently in the computer memory
C. Integers cannot be literals while floats can
D.  integers have a larger range
'''