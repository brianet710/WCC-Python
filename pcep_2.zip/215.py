'''
A value returned by the input() function is
'''

'''
A. a float 
B. an integer
C. a string
D.  a literal
'''