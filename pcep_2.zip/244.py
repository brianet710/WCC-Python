'''
If you want to loop through a dictionary's keys and values
you can use

A.  The items() method
B.  The elements() method
C.  The print() function
D.  The if-in statement



'''