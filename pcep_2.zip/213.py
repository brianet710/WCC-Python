'''
What is the output?

likes ="666",
print(type(likes))
      

A. False
B. Invalid syntax since a comma should not be there.
C.  <class 'str'>
D.  <class 'tuple'>

'''