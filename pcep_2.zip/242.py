'''
What is the output?

m = []
m.insert(333, 333)
print(m)

A.  []
B.  [333]
C.  code is erroneous
D.  result cannot be predicted


'''