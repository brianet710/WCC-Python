'''
What is the output of the following?

for x in range(-1, 1, 3):
    if x > 0: print(x)

else:
    print ("else:", x)    


A. else: -1
B. -1
C. "else' x
D. -1, 1, 3  


'''