'''
What is the output?
'''
my_tuple = (3.14, "trumpet",  [-1,1])
my_tuple[2] = "guitar"
del my_tuple[2]
print(my_tuple[2])
'''
A.  [-1, 1]
B.  "guitar"
C.  TypeError exception
D.  trumpet


'''