'''
What is the output?

text = "V is for vendetta"
for letter in text:
   if letter == "v":
       continue
   print (letter, end="")   

A. V is for endetta
B. V is for Vendetta
C. v
D. V
E. nothing is printed



'''