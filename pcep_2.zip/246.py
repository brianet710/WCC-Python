'''
To copy a dictionary you can use

A.  The move() method
B.  The paste() method
C.  The copy() method
D.  The duplicate statement

dict_1 = {"cost": 5}
dict_2 = dict_1
dict1_copy = dict_1.copy()
print(id(dict_1))
print(id(dict1_copy))
print(id(dict_2))
'''