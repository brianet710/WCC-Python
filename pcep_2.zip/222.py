'''
Select two representations of empty string.


A. s1 = []
B. s2 =''
C. s3 = ""
D.  s4 = empty()
'''