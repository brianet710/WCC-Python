'''
The following code snippet

sqr = (i**2 for i in range(10))
list(sqr)

A.  is erroneous  
B.  converts a generator object into a list
C.  defines a list comprehension
D.  creates an infinite list

'''
