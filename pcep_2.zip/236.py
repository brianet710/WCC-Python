'''
What is the output?

a = 'Pythonista'
i = 0
while i < len(a):
   i += 1
   pass
print('The value of i:', i)


A.  The value of i: 11 
B.  Syntax error
C.  The value of i: 1
D.  The value of i: 10

'''