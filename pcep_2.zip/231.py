'''
What is the output?

text = "PCEP exam"
for letter in text:
    if letter == "C"
        break
    print(letter, end = "")    
A. C
B. P
C. nothing
D. The code is erroneous


'''