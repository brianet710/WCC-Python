'''
The user inputs 'Java' when prompted. What is the output?
'''
language = input()
print(3*language)

'''
A.  Java Java Java
B.  code is erroneous
C.  3*Java
D   JavaJavaJava
'''