'''
Create a for loop that counts from 3 to 8 and prints
numbers divisible by 2 to the screen


A. 
for i in range(3,8):
    if i%2 == 0: print (i)
B. 
for i in range(3,9):
    if i%2 == 0: print (i)
C. 
for i in range(3,9):
    if i // 2 == 0: print(i)
D.  
for i in range(3,8):
    if i // 2: print(i)

'''