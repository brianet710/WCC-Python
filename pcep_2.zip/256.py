'''
What is the output?
'''
def fun(x = 4, y = -5):
    y -= 1
    return x * y * 1
print(fun())

'''
A.  SyntaxError
B.  20
C.  -20
D.  -24

'''
