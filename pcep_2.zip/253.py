'''
What is the output?
'''
def fun(inp=2, fun=3):
    return 5

print(fun())

'''
A.  
B.  
C.  
D.  

'''
