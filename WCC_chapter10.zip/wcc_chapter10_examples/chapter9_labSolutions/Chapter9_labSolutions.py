#1
class Vehicle:
    def __init__(self, make, model):
        self.make = make
        self.model = model
v1 = Vehicle("Ford", "Mustang")
v2 = Vehicle("Toyota", "Camry")
print(v1.make, v2.model)
print()
#2
class Vehicle:
    def __init__(self, make, model):
        self.make = make
        self.model = model
    
    def print_info(self):
        print("make =",self.make)
        print("model =",self.model)
v3 = Vehicle("Maserati", "Levante")
v4 = Vehicle("Porsche", "944")
v3.print_info()
v4.print_info()
print()
#3
class Vehicle:
    def __init__(self, make, model):
        self.make = make
        self.model = model
class Boat(Vehicle):
    def __init__(self, make, model, poweredBy):
        super().__init__(make, model)
        self.poweredBy = poweredBy
b1 = Boat(make="Regal", model="Bowrider", poweredBy="sail")
b2 = Boat(make="Searay", model="Sundancer", poweredBy="motor")
print(b1.make, b1.model, b1.poweredBy)
print(b2.make, b2.model, b2.poweredBy)
print()