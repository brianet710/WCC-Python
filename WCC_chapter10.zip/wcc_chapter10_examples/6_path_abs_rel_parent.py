#Absolute, relative & parent directory references
from pathlib import Path

# Current Working Directory
cwd = Path.cwd()
# User's Home Directory
home = Path.home()
print()
print(f"Current working directory: {cwd}")
print()
print(f"Home directory: {home}")
print()
# Absolute path reference on Windows (use raw)
path = Path(r"C:\test\haiku.txt")  #CREATE c:\test\haiku.txt for this to work !!!
#print(path.read_text())
#print()
#Relative path reference on Windows
path = Path("data/everyday.txt")
# reading a file from a path using read_text
print(path.read_text())
print()
#Relative path to a parent directory
path=Path("../emilyd.txt")
print(path.read_text())
print()