import csv
from pathlib import Path

# Create a Path object for the CSV file
file_path = Path("data/states.csv")

# Open the file in read mode
with file_path.open('r') as file:
    # Create a CSV reader
    reader = csv.reader(file)

    # Iterate over the rows in the CSV file
    for row in reader:
        print(row)