import pandas as pd

cities = pd.DataFrame([['Sacramento', 'California', 12.5], ['Miami', 'Florida', 5.2]], columns=['City', 'State', 'Population'])
cities.to_csv('cities.csv', index=False)