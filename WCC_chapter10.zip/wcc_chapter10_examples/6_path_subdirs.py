#example of data 3 levels "down"
from pathlib import Path

path = Path('data/subdir1/subdir2/racin.txt')
contents = path.read_text()

lines = contents.splitlines()
for line in lines:
    print(line)
print()

'''
data is a child of the current directory containing this script.
subdir1 is a child of data.
subdir2 is a child of subdir1.
'''
