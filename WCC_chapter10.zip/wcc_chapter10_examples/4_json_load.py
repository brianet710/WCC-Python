'''
json.load() takes a file object and returns the json object.
Deserializes the JSON data into a Python object (e.g., a dictionary or list).
'''
import json
#open the file to read from it

filename = 'data/employees_dict.json'
#filename='data/employees_list.json'
with open(filename) as f:
    data = json.load(f) #read file data into dict or list
print(type(data))
print(data)

# Closing file
#f.close() #with open handles this
