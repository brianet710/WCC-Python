'''
Pandas is a Python library for data manipulation and analysis.
It offers data structures and operations for manipulating numerical
tables and time series. Pandas is built upon another Python library,
Numpy'''

#Pandas: read csv from relative path
import pandas as pd

# Relative path
file_path = 'data/homeSales.csv'
#absolute path
#file_path = "E:\WCC_valhalla\Python\Examples_fa24\chapter10\Week10Examples\Week10_Examples\data\homeSales.csv"
df = pd.read_csv(file_path)

# Display the DataFrame
print(df)

#print(df.head())