#Pandas select specific columns
import pandas as pd


# Read specific columns from CSV file
columns = ['Sold',' List']  # Column Names (include spaces)
#columns = [0, 1]  # Column Indexes
df = pd.read_csv('data/homeSales.csv', usecols=columns)

# Display the DataFrame with specific columns
print(df)