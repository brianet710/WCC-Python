#Pandas get csv from Internet
#https://github.com/datablist/sample-csv-files
import pandas as pd

# URL to the CSV file
url = 'https://drive.google.com/uc?id=13a2WyLoGxQKXbN_AIjrOogIlQKNe9uPm&export=download'

# Read CSV file from URL into pandas DataFrame
df = pd.read_csv(url)

# Display the DataFrame
print(df)