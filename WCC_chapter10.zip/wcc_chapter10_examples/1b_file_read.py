'''
open() has been around since the early days of Python.
Widely used and familiar: Many developers are comfortable with open() 
due to its long history and straightforward usage.
'''
# set relative path and file variables
#states.txt is in the data folder 
#The data folder is a child of the folder containing this py file
filename = 'data/states.txt'

# file contents are available via the 'file_object'
# f = open(filename, mode)    mode defaults to read
# the  open function returns a file object

with open(filename) as file_object:
    data = file_object.read()

print(data)
print(type(data)) #data is a string
