
import sys
try:
    print(10/0)
# If the 'Try' block generates a ZeroDivisionError,
# run some warning code instead of producing a traceback error.
# This is known as 'catching' or 'handling' an 'exception'.
except ZeroDivisionError:
    print("The demoninator cannot be 0!")
    sys.exit('Program exiting because..fill in the blank') # force the program to end
print("")
print("We can choose not to exit and our program will continue") 

