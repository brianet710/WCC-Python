#read a csv file using csv.reader()
#The reader method returns an object of the csv class
import csv
with open('data/55aschool.csv', 'r') as file:
    reader = csv.reader(file)
    print(next(reader)) #print the header
    print(next(reader)) #print first record
    print(next(reader)) #print next record
#print the records/observations
    for row in reader:
      print(row)

# The reader keeps track of what line in the file has been read.