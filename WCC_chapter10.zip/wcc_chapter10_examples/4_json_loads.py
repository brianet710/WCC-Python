'''
Source of Data: load() reads from a file, while loads() reads from a string.
"s" for String: The "s" in loads() stands for "string".'''
import json
json_string = """
{
    "beatles": {
        "Paul": "bass",
        "John": "guitar",
        "George": "lead guitar",
        "Ringo":"drums",
        "albums": ["Rubber Soul","Abbey Road", "Let it Be"],
        "concert schedule": null,
        "great band":true
    }
}
"""
print(type(json_string))
data = json.loads(json_string)
print(type(data))
print(data)
# Note the differences between the string and the JSON data, true&none
