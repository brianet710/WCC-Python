''' Factorial of a number using recursion
Function recursion refers to a function which calls itself
https://www.w3schools.com/python/gloss_python_function_recursion.asp
'''
def recur_factorial(n):
   if n == 1:
       return n
   else:
       return n*recur_factorial(n-1)

num = 5
print("The factorial of", num, "is", recur_factorial(num))