# Factorial of a number using recursion
def get_number():
    nbr = int(input('Please enter the number: '))
    return nbr

def print_number(y):
  print("The factorial is", y)    

def factorial(n):
   if n == 1:
       return n
   else:
       return n*factorial(n-1)

def main():
    while True:
      users_number = get_number()
      if users_number == 'quit':
         break
      solution = factorial(users_number)
      print_number(solution)

if __name__ == "__main__":
    main()

